#!/usr/local/bin/python3.6
import cgi
import cgitb; 
cgitb.enable()
import csv
import json
import pymongo
from pymongo import MongoClient
from pprint import pprint
print("Content-type:text/html \r\n\r\n")
print("<HTML>")
print("<HEAD>")
print("</HEAD>")
print("<BODY>")

# Client=MongoClient("mongodb://apacbi_datalab_user:y#yzR85c_q$9j5B@aumel21db10v/datalab")
Client=MongoClient("mongodb://localhost:27017/python")
db=Client.datalab
collection=db["TestCollection"]

page = open("FinanceBot.json", 'r')
parsed = json.loads(page.read())

for item in parsed["Records"]:
    collection.insert(item)

print(parsed["Records"])
print("</BODY>")
print("</HTML>") 
