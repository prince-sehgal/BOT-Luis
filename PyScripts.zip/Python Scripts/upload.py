#!/usr/local/bin/python3.6
import csv
import json
import glob
import cgi, os
import cgitb; cgitb.enable()
import pymongo
from pymongo import MongoClient
from pprint import pprint
import time
import datetime
ts = time.time()
st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
print("Content-type:text/html \r\n\r\n")
print("<HTML>")
print("<HEAD>")
print("</HEAD>")
print("<BODY>")

try: 
    import msvcrt
    msvcrt.setmode (0, os.O_BINARY) 
    msvcrt.setmode (1, os.O_BINARY) 
except ImportError:
    pass

form = cgi.FieldStorage()


fileitem = form['file']


if fileitem.filename:
    
    fn = os.path.basename(fileitem.filename)
    f=fn.split('\\')[-1]
    FileName=f
    FileExtention=fn.split('.')[-1]
    open(f, 'wb').write(fileitem.file.read())
    message = 'The file "' + f + '" was uploaded successfully'

else:
    message = 'No file was uploaded'
