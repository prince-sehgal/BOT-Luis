import cgi, cgitb
print "Content-type: text/html\n\n"    #for showing print on HTML
data = cgi.FieldStorage()
argument = data["webArguments"].value    #argument = name of PLC i need to fetch
#some script for connecting to PLC and reading current value of 
#variable  with name "argument", in this example "aiTemperature"
print plcVar