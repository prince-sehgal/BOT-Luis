# import csv
# import sys

# file_name = sys.argv[1]
# with open(file_name) as File:
#     reader = csv.reader(File, delimiter=',', quotechar=',',
#                         quoting=csv.QUOTE_MINIMAL)
#     for row in reader:
#         print(row)



import cgi, cgitb
import csv 
import sys
cgitb.enable()  # for troubleshooting

#the cgi library gets vars from html
data = cgi.FieldStorage()
#this is the actual output
print ("Content-Type: text/html\n")

# file_name = sys.argv[1]
print("<table border=1>")

# with open(data["name"].value) as File:
    with open('../CSVFiles/qeustions.csv') as File:
    reader = csv.reader(File, delimiter=',', quotechar=',',
                        quoting=csv.QUOTE_MINIMAL)
    for row in reader:
        print("<tr>")
        i = 0
        while i < len(row):
            print("<td>"+row[i]+"</td>")
            i += 1
        print("</tr>")


print("</table>")
        # print(row)
# print ("Name: " + data["name"].value)
# print("<br/>")
# print ("Value: " + data["val"].value)
# print("<br/>")
# print (data)
