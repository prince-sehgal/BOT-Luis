process.env.TMPDIR = './tempdata/';


var restify = require('restify');
var Store = require('./store');
var JsonAPI = require('./jsonapi');

var csv = require("csvtojson");

var fs = require('fs');
var crypto = require('crypto');


// Setup Restify Server
var server = restify.createServer();


 server.listen(process.env.port || process.env.PORT || 3979, function () {
                                console.log('%s listening to %s', server.name, server.url);
                            });

                            server.use(restify.bodyParser());
                            server.use(restify.queryParser());	
                            server.use(function crossOrigin(req,res,next){
                                res.header("Access-Control-Allow-Origin", "*");
                                res.header("Access-Control-Allow-Headers", "X-Requested-With");
                                return next();
                            }); 


var postFile = function(req, res, next) {

 var collectionName = req.files.file.name.substr(0,req.files.file.name.indexOf('.'));
  var buf = crypto.randomBytes(16);
  var dataFileName =  buf.toString('hex')+'.csv';

  fs.rename(req.files.file.path, dataFileName, function (err) {
                if (err) 
                    res.json({
                            error:err
                       });  
                        fs.unlink(req.files.file.path, function() {
                                if (err) throw err;
                                var stream = fs.createReadStream(dataFileName);
                                csv()
                                .fromFile(dataFileName)
                                .on("end_parsed",function(jsonArrayObj){ 
                                    Store.deleteCubeData(collectionName)
                                    .then(function () {
                                        Store.insertCubeData(jsonArrayObj,collectionName)
                                        .then(function () {
                                            fs.unlink(dataFileName, function() {
                                                if (err) throw err;
                                            });
                                            var userName = req.params.userName;

                                            var result = {
                                                file: collectionName,
                                                path:'datalab',
                                                datetime:req.params.dateTime,
                                                user:req.params.userName,
                                                type:'mongo'
                                            };
                                            Store.addLogs(result)
                                                .then(function () {
                                                res.json({
                                                            status:"complete",
                                                                collection: collectionName
                                                        });   
                                                });
                                                
                                            });
                                                 });
                                    });
                                    stream.destroy();
                        });
            });
};

var removePublishment = function(req, res, next){
// Store.removePublishment(req.params.pyId)
//     .then(function () {
//         res.json({
//                     status:"complete"
//                 });   
//         });
Store.getPublishedPyId(req.params.pyId)
    .then(function (data){
 
           Store.getFilePath(data[0]._id.pyId)
                    .then(function (pyData){
                        console.log(pyData);
                        var pyFiles = [];
                        pyFiles.push(pyData[0]._id.filePath);
                        
                                Store.countPublishedInsights(data[0]._id.pyId) 
                                    .then(function (rowCount){
                                        if(rowCount <= 1)
                                            {
                                            Store.removePublishment(req.params.pyId)
                                            .then(function () {
                                                Store.updateLogs(pyFiles,true)
                                                .then(function () {
                                                        res.json({
                                                                    status:"complete"
                                                                });   
                                                        });
                                                });
                                            }
                                            else{
                                                 Store.removePublishment(req.params.pyId)
                                            .then(function () {
                                                res.json({
                                                            status:"complete"
                                                        });   
                                                });
                                            }
                        }); 
                    });
    });
  
}
var removeLogs = function(req, res, next){
    Store.getFilePath(req.params.pyId)
        .then(function (fileData){
                if(fileData[0]._id.filePath.indexOf('.py')>-1){
                    var text = fs.readFileSync(fileData[0]._id.filePath,'utf8');

                                    var csvFiles = [];
                                    var seprator = 'CSVFiles/';
                                    
                                    text.split(seprator).forEach(function(item){
                                        if(item.indexOf('.csv')>-1){
                                    csvFiles.push(seprator+item.substring(0,item.indexOf('.csv')+4));
                                        }
                                    });
                                    //lock csv files by changing removable property to false
                                    Store.updateLogs(csvFiles,true)
                                    .then(function () {
                                        fs.unlink(fileData[0]._id.filePath, function() {         
                                            Store.removeLogs(req.params.pyId)
                                                    .then(function () {
                                                    res.json({
                                                                status:"complete"
                                                            });   
                                                    });
                                            });
                                    }); 
                }
                else{
                    fs.unlink(fileData[0]._id.filePath, function() {         
                        Store.removeLogs(req.params.pyId)
                                .then(function () {
                                res.json({
                                            status:"complete"
                                        });   
                                });
                        });
                }
    });
}
var uploadCSVFile = function(req, res, next) {
    var fileName = req.files.file.name;
// var dataFileName = "PythonFiles/" +req.files.file.name;

var buf = crypto.randomBytes(16);
var filePath = "CSVFiles/" + buf.toString('hex')+'.csv';
var userName = req.params.userName;

var result = {
    file: fileName,
    path:filePath,
    datetime:req.params.dateTime,
    user:req.params.userName,
    type:'csv',
    removable:true
};


// var dataFileName = "CSVFiles/" +req.files.file.name;

    fs.rename(req.files.file.path, filePath, function (err) {
        if (err) 
            res.json({
                    error:err
                });  
 Store.addLogs(result)
                    .then(function () {
                    res.json({
                                status:"complete"
                            });   
                    });
                // fs.readdir("CSVFiles/", (err, files) => {
                // files.forEach(file => {
                //     console.log(file);
                // });
                // });
    });
};
var getInsights = function(req, res, next){
   Store.getInsights(req.params.userName)
                    .then(function (output) {
                    res.json({
                                resultset: output
                            });   
                    });
};
var publishInsights = function(req, res, next){

var result = {
    pyId: req.params.pyId,
    title:req.params.title,
    description:req.params.description,
    datetime:req.params.dateTime,
    user:req.params.user,
    removable:true
};
   Store.publishInsights(result)
                    .then(function (output) {
                         Store.getFilePath(req.params.pyId)
                    .then(function (pyData){

                        var pyFiles = [];
                        pyFiles.push(pyData[0]._id.filePath);
                        
                        Store.updateLogs(pyFiles,false)
                         .then(function () {
                            res.json({
                                        publishment: output,
                                        status:"complete"
                                    });  
                        }); 
                    });
                    // res.json({
                    //             publishment: output,
                    //             status:"complete"
                    //         });   
                    });
};

var uploadPYFile = function(req, res, next) {
var fileName = req.files.file.name;
// var dataFileName = "PythonFiles/" +req.files.file.name;

var buf = crypto.randomBytes(16);
var filePath = "PythonFiles/" + buf.toString('hex')+'.py';
var userName = req.params.userName;

var result = {
    file: fileName,
    path:filePath,
    datetime:req.params.dateTime,
    user:req.params.userName,
    type:'py',
    removable:true
};
    fs.rename(req.files.file.path, filePath, function (err) {
        if (err) 
            res.json({
                    error:err
                });  
                Store.addLogs(result)
                    .then(function () {
                        var text = fs.readFileSync(filePath,'utf8');

                        var csvFiles = [];
                        var seprator = 'CSVFiles/';
                        
                        text.split(seprator).forEach(function(item){
                            if(item.indexOf('.csv')>-1){
                        csvFiles.push(seprator+item.substring(0,item.indexOf('.csv')+4));
                            }
                        });
                        //lock csv files by changing removable property to false
                        Store.updateLogs(csvFiles,false)
                         .then(function () {
                            res.json({
                                        status:"complete"
                                    });  
                        }); 
                    });
                // fs.readdir("PythonFiles/", (err, files) => {
                // files.forEach(file => {
                //     console.log(file);
                // });
                // });
      
    });
};
var getCSVData = function(req, res, next) {
           Store.getLogs('csv',req.params.userName)
                        .then(function (data){
                            res.json({
            list:data
        });   
                        });  
       
};
var getMongoData = function(req, res, next) {
           Store.getLogs('mongo')
                        .then(function (data){
                            res.json({
            list:data
        });   
                        });  
};
   
var getPyData = function(req, res, next) {
         Store.getLogs('py',req.params.userName)
                        .then(function (data){
                            res.json({
            list:data
        });   
                        });  
};


var getPyList = function(req, res, next) {
    fs.readdir("PythonFiles/", (err, files) => {
        res.json({
            list:files
        });   
    });
};

var getCsvList = function(req, res, next) {
     fs.readdir("CSVFiles/", (err, files) => {
       res.json({
            list:files
        });  
    });
};


var pushData = function(req, res, next) {
//req.params.CubeId
     JsonAPI.getSession().then(function(session){
    JsonAPI.getCubeData(session.authToken,req.params.CubeId)
    .then(function(result){
      Store.deleteCubeData(req.params.CollectionName)
                .then(function () {
                    Store.insertCubeData(result,req.params.CollectionName)
                    .then(function () {
                                    res.json({
                                                status:"complete"
                                            });   
                });
            });
        }); 
    });
};

var getCubeData = function(req, res, next) {
//req.params.CubeId
     JsonAPI.getSession().then(function(session){
    JsonAPI.getCubeData(session.authToken,req.params.CubeId)
    .then(function(result){
        res.json({
                    data:result
                });   
        }); 
    });
};



var getPythonOutput = function(req, res, next) {
    var success, exception;
    Store.getPyID(req.params.pyId)
            .then(function (PyDataSet){
            Store.getFilePath(PyDataSet[0]._id.pyId)
                    .then(function (pyData){
                        const { spawn } = require('child_process');
//                      const pyProg = spawn('python',[pyData[0]._id.filePath]);
                        const pyProg = spawn('python3.6',[pyData[0]._id.filePath]);
                        pyProg.stdout.on('data', function(data) {
                        success = data.toString();
                        });

                        pyProg.stderr.on('data', function(data) {
                        exception = data.toString();
                        });
                        pyProg.on('exit', function(code) {
                            res.json({
                                data:success,
                                error: exception,
                                image:pyData[0]._id.filePath+'.png',
                                output:code.toString()
                                    });   
                        });
                    }); 
            });
};


var api = function(req, res, next) {

//req.params.CubeId

res.json({
    status:"connected"
});   
};


server.post('/api/GetPythonOutput', getPythonOutput);
server.get('/api/GetPyList', getPyList);
server.get('/api/GetPyData', getPyData);
server.get('/api/GetMongoData', getMongoData);
server.post('/api/PublishInsights', publishInsights);
server.get('/api/getInsights', getInsights);
server.get('/api/GetCSVData', getCSVData);
server.get('/api/GetCsvList', getCsvList);
server.post('/api/UploadCSVFile', uploadCSVFile);
server.post('/api/RemoveLogs', removeLogs);
server.post('/api/RemovePublishment', removePublishment);
server.post('/api/UploadPythonFile', uploadPYFile);
server.post('/api/PostFile', postFile);
server.post('/api/PushData', pushData);
server.post('/api/GetCubeData', getCubeData);
server.get('/api', api);
server.get( /\/(.*)?.*/,restify.plugins.serveStatic({directory: './PythonFiles',}));
