import matplotlib

matplotlib.use('Agg')

import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import csv
import json
import glob
import cgi, os
import cgitb; cgitb.enable()
import pymongo
from pymongo import MongoClient
from pprint import pprint
import time
import os
import datetime
ts = time.time()
st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
Client=MongoClient("mongodb://apacbi_datalab_user:y#yzR85c_q$9j5B@aumel21db10v/datalab")
db=Client.datalab
collection=db["HeadCountAnalysis"]
GenderSum=[{'$group':{'_id':'$Gender', 'sum':{'$sum': '$Initial_HeadCount'}}}]
GenderAggr=collection.aggregate(pipeline=GenderSum)
pipe = [{'$group': {'_id': None, 'total': {'$sum': '$Initial_HeadCount'}}}]
x=list(collection.aggregate(pipeline=pipe))
Initial_HeadCount=[move['sum'] for move in GenderAggr]

Year_End=[{'$group':{'_id':'$Gender', 'sum':{'$sum': '$Year_End_Current_HeadCount'}}}]
Year_End_HeadCount=collection.aggregate(pipeline=Year_End)
Year_End_Current_HeadCount=[check ['sum'] for check in Year_End_HeadCount]
print(Initial_HeadCount)
print(Year_End_Current_HeadCount)

n_groups = 2
fig, ax = plt.subplots()
index = np.arange(n_groups)
bar_width = 0.35
opacity = 0.8
rects1 = plt.bar(index, Initial_HeadCount, bar_width,
                 alpha=opacity,
                 color='b',
                 label='Initial HeadCount')
rects2 = plt.bar(index + bar_width, Year_End_Current_HeadCount, bar_width,
                 alpha=opacity,
                 color='g',
                 label='Current/Year End HeadCount')
plt.xlabel('Person')
plt.ylabel('Scores')
plt.title('HeadCount Analysis by Gender')
plt.xticks(index + bar_width, ('Male', 'Female'))
plt.legend()
plt.tight_layout()
#plt.savefig('/var/www/cgi-bin/files/plot5.png', format='png')
plt.savefig(os.path.realpath(__file__)+'.png',trasparent=True,bbox_inches='tight')

