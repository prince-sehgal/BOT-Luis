function getPanel(element,panelName){
if($(element).hasClass("active")){
$(element).removeClass("active");
$("div[nm='"+panelName+"']").css('visibility', 'hidden');
}
else{
    $(element).addClass('active');
$("div[nm='"+panelName+"']").css('visibility', 'visible');
}
}