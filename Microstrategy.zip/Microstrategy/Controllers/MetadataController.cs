﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Microstrategy.Controllers
{
    public class MetadataController : Controller
    {
        private string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MetadataConnection"].ToString();
        //
        // GET: /Helper/
        public MetadataController()
        {

        }
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetProjectList(int ProjectKey)
        {
            string query = "Select distinct proj_guid as IS_PROJ_ID, PROJ_NAME as IS_PROJ_NAME from  [APAC_BI_DEV_EM].[dbo].[VW_BOT]";
            List<Projects> projectList = new List<Projects>();
            //if (GeographyKey > 0)
            //    query = string.Format("{0} where GeographyKey = {1}", query, GeographyKey);
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        projectList.Add(
                            new Projects
                            {
                                IS_PROJ_ID = reader["IS_PROJ_ID"].ToString(),
                                IS_PROJ_NAME = reader["IS_PROJ_NAME"].ToString()
                            }
                        );
                    }
                }
                return Json(projectList, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult GetReportList(string ProjectName)
        {
            string query = "Select distinct proj_guid as IS_PROJ_ID, PROJ_NAME as IS_PROJ_NAME ,rep_Guid as IS_DOC_ID, REP_NAME AS IS_DOC_NAME from  [APAC_BI_DEV_EM].[dbo].[VW_BOT] where rep_name like 'BOT_%'";
            List<Reports> reportList = new List<Reports>();
            //if (GeographyKey > 0)
            //    query = string.Format("{0} where GeographyKey = {1}", query, GeographyKey);
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        reportList.Add(
                            new Reports
                            {
                                IS_PROJ_ID = reader["IS_PROJ_ID"].ToString(),
                                IS_PROJ_NAME = reader["IS_PROJ_NAME"].ToString(),
                                IS_DOC_ID = reader["IS_DOC_ID"].ToString(),
                                IS_DOC_NAME = reader["IS_DOC_NAME"].ToString()
                            }
                        );
                    }
                }
                return Json(reportList, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetReportListByMetric(string CountType)
        {
            string query = string.Empty;
            if (CountType.ToLower() == "premium")
                query = "Select distinct proj_guid as IS_PROJ_ID, PROJ_NAME as IS_PROJ_NAME ,rep_Guid as IS_DOC_ID, REP_NAME AS IS_DOC_NAME from  [APAC_BI_DEV_EM].[dbo].[VW_BOT] where rep_name like 'BOT_%' and MET_GUID = '7DBCE75246DF756D9AC858A9906EEE4F'";
            else if (CountType.ToLower() == "claims")
                query = "Select distinct proj_guid as IS_PROJ_ID, PROJ_NAME as IS_PROJ_NAME ,rep_Guid as IS_DOC_ID, REP_NAME AS IS_DOC_NAME from  [APAC_BI_DEV_EM].[dbo].[VW_BOT] where rep_name like 'BOT_%' and MET_GUID = '950D383D41D2AC0EC66F939D5BC37861'";

            List<Reports> reportList = new List<Reports>();
            //if (GeographyKey > 0)
            //    query = string.Format("{0} where GeographyKey = {1}", query, GeographyKey);
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        reportList.Add(
                            new Reports
                            {
                                IS_PROJ_ID = reader["IS_PROJ_ID"].ToString(),
                                IS_PROJ_NAME = reader["IS_PROJ_NAME"].ToString(),
                                IS_DOC_ID = reader["IS_DOC_ID"].ToString(),
                                IS_DOC_NAME = reader["IS_DOC_NAME"].ToString()
                            }
                        );
                    }
                }
                return Json(reportList, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult GetCubeCount(string CountType)
        {
            string query = string.Empty;
                query = @"SELECT  COUNT(DISTINCT(CVW.IS_CUBE_NAME)) AS CUBE_COUNT, MAX(CVW.IS_CUBE_NAME) AS CUBE_NAME FROM VW_BOT BOT LEFT JOIN IS_CUBE_VIEW CVW ON  (BOT.DEP_CUBE_GUID=CVW.IS_CUBE_GUID) WHERE BOT.PROJ_ID=7 AND BOT.REP_LOC LIKE ('%PUBLIC OBJECTS\REPORTS\BOT%') AND BOT.MET_NAME LIKE ('%"+CountType.ToLower()+"%') AND BOT.REPCTYPE_IND=8";

            HeadCount obj = new HeadCount();
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if(reader.Read())
                    {
                        obj = new HeadCount()
                        {
                            Head = reader["CUBE_NAME"].ToString(),
                            Count = int.Parse(reader["CUBE_COUNT"].ToString())
                        };
                    }
                }
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetReportCount(string CountType)
        {
            string query = string.Empty;
            if(CountType.ToLower() == "premium")
                query = "select count(distinct REP_ID) as 'count' from VW_BOT where MET_GUID = '7DBCE75246DF756D9AC858A9906EEE4F' and rep_name like 'BOT_%'";
            else if (CountType.ToLower() == "claims")
                query = "select count(distinct REP_ID) as 'count' from VW_BOT where MET_GUID = '950D383D41D2AC0EC66F939D5BC37861' and rep_name like 'BOT_%'";

            HeadCount obj = new HeadCount();
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    obj = new HeadCount()
                    {
                        Head = CountType,
                        Count = int.Parse(cmd.ExecuteScalar().ToString())
                    };
                  
                }
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
        }
    }
    public class HeadCount
    {
        public int Count;
        public string Head;
    }
    public class Reports
    {
        public string IS_PROJ_ID;
        public string IS_PROJ_NAME;
        public string IS_DOC_ID;
        public string IS_DOC_NAME;
    }
    public class Projects
    {
        public string IS_PROJ_ID;
        public string IS_PROJ_NAME;
    }
}
