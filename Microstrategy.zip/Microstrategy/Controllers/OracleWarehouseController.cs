﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Oracle.DataAccess.Client;

namespace Microstrategy.Controllers
{
    public class Perspectives
    {
        public string Client_Key;
        public string Perspective_Code;
    }
    public class OracleWarehouseController : Controller
    {
        private string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["OracleConnection"].ToString();
        //
        // GET: /OracleWarehouse/

        public ActionResult Index()
        {
            return View();
        }
        public JsonResult GetAllData()
        {
            string query = "select distinct Client_Key,Perspective_Code from AGG_AGING_ROLE_MTHLY where rownum <=1000";

            List<Perspectives> perspectivesData = new List<Perspectives>();
            OracleConnection connection = new OracleConnection(connectionString);
            {
                using (OracleCommand cmd = new OracleCommand(query, connection))
                {
                    connection.Open();
                    OracleDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        perspectivesData.Add(
                            new Perspectives
                            {
                                Client_Key = reader["Client_Key"].ToString(),
                                Perspective_Code = reader["Perspective_Code"].ToString()
                            }
                        );
                    }
                }
                return Json(perspectivesData, JsonRequestBehavior.AllowGet);
            }
        }

    }
}
