﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;


namespace Microstrategy.Controllers
{
    public class Premium
    {
        public string Header;
        public string Value;
    }
    public class Claims
    {
        public string Header;
        public string Value;
    }

    public class FinanceData
    {
        public string Bus_Member;
        public string Geo_Member;
        public double CYR;
        public double TOR; 
    }
    public class WarehouseController : Controller
    {
        private string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MSTRConnection"].ToString();
        //
        // GET: /warehouse/

        public ActionResult Index()
        {
            return View();
        }
        public JsonResult GetClaimsByDimension(string Dimension)
        {
            string query = "select	'Total' as Header,round(sum(a11.MiscAmt1),0)  as AggregatedClaims from APAC.R_CAD_Fact_Claim_CN a11 where a11.SourceDbID in (88)";
            if (Dimension == "Product")
                query = "select a12.MercerProductClass1Code as Header, round(sum(a11.MiscAmt1),0) as AggregatedClaims from APAC.R_CAD_Fact_Claim_CN a11 join APAC.R_CAD_Dim_BenefitProduct a12 on (a11.BenefitProductKey = a12.BenefitProductKey and a11.SourceDbID = a12.SourceDbID) where a11.SourceDbID in (88) group by a12.MercerProductClass1Code";
            else if (Dimension == "Client")
                query = "select	a12.OrganizationName  as Header,round(sum(a11.MiscAmt1),0) as AggregatedClaims from APAC.R_CAD_Fact_Claim_CN a11 join APAC.R_CAD_Dim_Organization_CN	a12 on 	(a11.ClientKey = a12.OrganizationKey and a11.SourceDbID = a12.SourceDbID) where a11.SourceDbID in (88) group by a12.OrganizationName";
            else if (Dimension == "Region")
                query = "select a13.GeographyName as Header,round(sum(a11.MiscAmt1),0) as AggregatedClaims from APAC.R_CAD_Fact_Claim_CN a11 join APAC.R_CAD_Dim_Organization_CN	a12 on 	(a11.ClientKey = a12.OrganizationKey and a11.SourceDbID = a12.SourceDbID) INNER JOIn APAC.[Vw_CAD_Dim_Geography] as a13 on (a12.SourceDbID = a13.SourceDbID and  a12.GeographyKey = a13.GeographyKey) where a11.SourceDbID in (88) group by a13.GeographyName";
            else if (Dimension == "SubProduct")
                query = "select a12.MercerProductClass2Code as Header, round(sum(a11.MiscAmt1),0) as AggregatedClaims from APAC.R_CAD_Fact_Claim_CN a11 join APAC.R_CAD_Dim_BenefitProduct a12 on (a11.BenefitProductKey = a12.BenefitProductKey and a11.SourceDbID = a12.SourceDbID) where a11.SourceDbID in (88) group by a12.MercerProductClass2Code";
            List<Claims> claimsData = new List<Claims>();
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        claimsData.Add(
                            new Claims
                            {
                                Header = reader["Header"].ToString(),
                                Value = reader["AggregatedClaims"].ToString()
                            }
                        );
                    }
                }
                return Json(claimsData, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult GetPremiumByDimension(string Dimension)
        {
            string query = "select	'Total' as Header,round(sum(a11.PremiumAmt),0)  as AggregatedPremium from	APAC.R_CAD_Fact_Premium	a11 where	((a11.PremiumType in (N'Initial')  or a11.PremiumType in (N'Refunded')  or a11.PremiumType in (N'Added'))  and a11.SourceDbID in (88))";
            if (Dimension == "Client")
                query = "select a13.OrganizationName as Header, round(sum(a11.PremiumAmt),0)  AS AggregatedPremium from APAC.R_CAD_Fact_Premium a11 join APAC.R_CAD_Dim_Policy a12 on  (a11.PolicyKey = a12.PolicyKey and  a11.SourceDbID = a12.SourceDbID) join APAC.R_CAD_Dim_Organization_CN a13 on  (a11.SourceDbID = a13.SourceDbID and  a12.ClientKey = a13.OrganizationKey) where ((a11.PremiumType in (N'Initial') or a11.PremiumType in (N'Refunded') or a11.PremiumType in (N'Added')) and a11.SourceDbID in (88)) group by a13.OrganizationName order by sum(a11.PremiumAmt) desc";
            else if (Dimension == "Product")
                query = "select	a12.ProductGroupCode as Header, round(sum(a11.PremiumAmt),0) as AggregatedPremium from	APAC.R_CAD_Fact_Premium	a11	join APAC.R_CAD_Dim_BenefitProduct	a12 on (a11.BenefitProductKey = a12.BenefitProductKey and a11.SourceDbID = a12.SourceDbID) where	((a11.PremiumType in (N'Initial') or a11.PremiumType in (N'Refunded') or a11.PremiumType in (N'Added')) and a11.SourceDbID in (88)) group by a12.ProductGroupCode ";
            else if (Dimension == "Region")
                query = "select top(5) a14.GeographyName AS Header, round(sum(a11.PremiumAmt),0)  AS AggregatedPremium from APAC.R_CAD_Fact_Premium a11 join APAC.R_CAD_Dim_Policy a12 on  (a11.PolicyKey = a12.PolicyKey and  a11.SourceDbID = a12.SourceDbID) join APAC.R_CAD_Dim_Organization a13 on  (a11.SourceDbID = a13.SourceDbID and  a12.ClientKey = a13.OrganizationKey) INNER JOIn APAC.[Vw_CAD_Dim_Geography] as a14 on (a13.SourceDbID = a14.SourceDbID and  a13.GeographyKey = a14.GeographyKey) where ((a11.PremiumType in (N'Initial') or a11.PremiumType in (N'Refunded') or a11.PremiumType in (N'Added')) and a11.SourceDbID in (88)) group by a14.GeographyName";
            else if (Dimension == "SubProduct")
                query = "select a12.SubProductGroupCode as Header, round(sum(a11.PremiumAmt),0) as AggregatedPremium from	APAC.R_CAD_Fact_Premium	a11	join APAC.R_CAD_Dim_BenefitProduct	a12 on (a11.BenefitProductKey = a12.BenefitProductKey and a11.SourceDbID = a12.SourceDbID) where	((a11.PremiumType in (N'Initial') or a11.PremiumType in (N'Refunded') or a11.PremiumType in (N'Added')) and a11.SourceDbID in (88)) group by a12.SubProductGroupCode";
            List<Premium> premiumData = new List<Premium>();
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        premiumData.Add(
                            new Premium
                            {
                                Header = reader["Header"].ToString(),
                                Value = reader["AggregatedPremium"].ToString()
                            }
                        );
                    }
                }
                return Json(premiumData, JsonRequestBehavior.AllowGet);
            }
        }
        string filterString = @"";
        public JsonResult GetFinanceMetric(string GroupByClause, string Filter, string Condition)
        {
            string query = "select avg(Current_Year_Revenue) as CYR, avg(Total_Opp_revenue) as TOR from [dbo].[LeadershipSummary] where Month = 'Mar 17'";
            if (GroupByClause != "" && Filter == "" && Condition == "")
                query = "select " + GroupByClause + ", avg(Current_Year_Revenue) as CYR, avg(Total_Opp_revenue) as TOR from [dbo].[LeadershipSummary] where Month = 'Mar 17' group by " + GroupByClause;
            else if (GroupByClause != "" && Filter == "" && Condition != "")
            {
                query = "select " + GroupByClause + ", avg(Current_Year_Revenue) as CYR, avg(Total_Opp_revenue) as TOR from [dbo].[LeadershipSummary] where Month = 'Mar 17' and "+Condition+" group by " + GroupByClause;
            }
            else if (GroupByClause == "" && Filter.Contains("geo_member"))
            {
                query = "select  avg(Current_Year_Revenue) as CYR, avg(Total_Opp_revenue) as TOR from [dbo].[LeadershipSummary] where Month = 'Mar 17' and geo_member in ('" + Filter.Substring(Filter.IndexOf("@") + 1) + "')";
            }
            else if (GroupByClause == "" && Filter.Contains("bus_member"))
            {
                query = "select  avg(Current_Year_Revenue) as CYR, avg(Total_Opp_revenue) as TOR from [dbo].[LeadershipSummary] where Month = 'Mar 17' and bus_member in ('" + Filter.Substring(Filter.IndexOf("@") + 1) + "')";
            }
            else if (GroupByClause == "" && Filter.Contains("@"))
            {
                query = "select  avg(Current_Year_Revenue) as CYR, avg(Total_Opp_revenue) as TOR from [dbo].[LeadershipSummary] where Month = 'Mar 17' and geo_member in ('" + Filter.Substring(0, Filter.IndexOf("@")) + "') and bus_member in ('" + Filter.Substring(Filter.IndexOf("@") + 1) + "')";
            }
            else
            {
                query = "select " + GroupByClause + ",avg(Current_Year_Revenue) as CYR,avg(Total_Opp_revenue) as TOR from [dbo].[LeadershipSummary] where Month = 'Mar 17'and " + GroupByClause + " in ('" + Filter + "') group by " + GroupByClause;
            }

            List<FinanceData> financeData = new List<FinanceData>();
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        FinanceData row = new FinanceData();
                        if (GroupByClause == "Bus_Member")
                            row.Bus_Member = reader["Bus_Member"].ToString();
                        if (GroupByClause == "Geo_Member")
                            row.Geo_Member = reader["Geo_Member"].ToString();
                        row.CYR = double.Parse(string.Format("0{0}",reader["CYR"]));
                        row.TOR = double.Parse(string.Format("0{0}", reader["TOR"]));
                        financeData.Add(row);
                    }
                }
                return Json(financeData, JsonRequestBehavior.AllowGet);
            }
        }

    }
}
