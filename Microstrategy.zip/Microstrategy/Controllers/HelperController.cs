﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Microstrategy.Controllers
{
    public class HelperController : Controller
    {
        private string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MSTRConnection"].ToString();
        //
        // GET: /Helper/
        public HelperController()
        {

        }
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult UploadFiles()
        {

            HttpFileCollectionBase files = Request.Files;
            if (files.Count > 0)
            {
                try
                {
                    //  Get all files from Request object  
                    for (int i = 0; i < files.Count; i++)
                    {
                        //string path = AppDomain.CurrentDomain.BaseDirectory + "Uploads/";  
                        //string filename = Path.GetFileName(Request.Files[i].FileName);  

                        HttpPostedFileBase file = files[i];
                        string fname;

                        // Checking for Internet Explorer  
                        if (Request.Browser.Browser.ToUpper() == "IE" || Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            fname = testfiles[testfiles.Length - 1];
                        }
                        else
                        {
                            fname = file.FileName;
                        }

                        // Get the complete folder path and store the file inside it.  
                        fname = Path.Combine(Server.MapPath("~/Uploads/"), fname);
                        file.SaveAs(fname);
                    }
                }
                catch (Exception ex)
                {
                    Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    return Json(new
                    {
                        statusCode = 400,
                        statusText = ex.Message,
                    }, JsonRequestBehavior.AllowGet);
                }

                return Json(new
                {
                    statusCode = 200,
                    statusText = "File uploaded Successfuly.",
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new
                {
                    statusCode = 200,
                    statusText = "File not attached.",
                }, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetGeographies(int GeographyKey)
        {
            string query = "select * from APAC.CAD_Dim_Geography";
            List<Geography> employee = new List<Geography>();
            if (GeographyKey > 0)
                query = string.Format("{0} where GeographyKey = {1}", query, GeographyKey);
            SqlConnection connection = new SqlConnection(connectionString);
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        employee.Add(
                            new Geography
                            {
                                GeographyKey = int.Parse(reader["GeographyKey"].ToString()),
                                GeographyCode = reader["GeographyCode"].ToString(),
                                GeographyName = reader["GeographyName"].ToString(),
                                UNNumericalCode = reader["UNNumericalCode"].ToString(),
                                CityCode = reader["CityCode"].ToString(),
                                CityName = reader["CityName"].ToString(),
                                StateCode = reader["StateCode"].ToString(),
                                StateName = reader["StateName"].ToString(),
                                ProvinceCode = reader["ProvinceCode"].ToString(),
                                ProvinceName = reader["ProvinceName"].ToString(),
                                CountryCodeAlpha2 = reader["CountryCodeAlpha2"].ToString(),
                                CountryCodeAlpha3 = reader["CountryCodeAlpha3"].ToString(),
                                CountryName = reader["CountryName"].ToString(),
                                ZoneCode = reader["ZoneCode"].ToString(),
                                ZoneName = reader["ZoneName"].ToString(),
                                RegionCode = reader["RegionCode"].ToString(),
                                RegionName = reader["RegionName"].ToString(),
                                MercerZoneCode = reader["MercerZoneCode"].ToString(),
                                MercerZoneName = reader["MercerZoneName"].ToString(),
                                MercerRegionCode = reader["MercerRegionCode"].ToString(),
                                MercerRegionName = reader["MercerRegionName"].ToString(),
                                SourceDbID = int.Parse(reader["SourceDbID"].ToString())
                            }
                        );
                    }
                }
                return Json(employee, JsonRequestBehavior.AllowGet);
            }
        }
    }
    public class Geography
    {
        public int GeographyKey;
        public string GeographyCode;
        public string GeographyName;
        public string UNNumericalCode;
        public string CityCode;
        public string CityName;
        public string StateCode;
        public string StateName;
        public string ProvinceCode;
        public string ProvinceName;
        public string CountryCodeAlpha2;
        public string CountryCodeAlpha3;
        public string CountryName;
        public string ZoneCode;
        public string ZoneName;
        public string RegionCode;
        public string RegionName;
        public string MercerZoneCode;
        public string MercerZoneName;
        public string MercerRegionCode;
        public string MercerRegionName;
        public int SourceDbID;
    }
}
