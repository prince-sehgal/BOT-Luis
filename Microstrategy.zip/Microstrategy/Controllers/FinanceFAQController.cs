﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;

namespace Microstrategy.Controllers
{
    public class FinanceFAQController : Controller
    {
        //
        // GET: /FinanceFAQ/

        public ActionResult Index()
        {
            return Redirect("http://10.197.131.61/Chatbot/Finance/chat.html?user=" + System.Web.HttpContext.Current.User.Identity.Name.Substring(System.Web.HttpContext.Current.User.Identity.Name.IndexOf("\\") + 1));
        }

    }
}
