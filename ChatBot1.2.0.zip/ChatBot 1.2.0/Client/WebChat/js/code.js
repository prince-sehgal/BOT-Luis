'use strict'
$(".overlay").hide();
$('#start-time').html(postTime());
$('#greeting-line').html(postGreetingLine());
var isIdentified = false;
var userName = '';
var botCounter = 900;
var botTimer = null;
var tabCount = 1;


function updateCounter(){
botCounter--;
if(botCounter == 0){
        $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Logging out session due to in-activity.<br>Please <a href="index.html">sign in</a> again.'+botEnd);
        $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
        $("#query-box").attr("disabled", true);
        $("#query-button").attr("disabled", true);
        $('#indicator')
        .removeClass('text-success')
        .addClass('text-red'); 
         $("#btn-refresh").attr("disabled", true);  
clearInterval(botTimer);
}
else if(botCounter == 450){
    $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Do you have any other query?'+botEnd);
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
}
}
function startInterval()
{
botTimer= setInterval("updateCounter()", 1000);
}

$(document)
    .one('focus.textarea', '.form-control', function(){
        var savedValue = this.value;
        this.value = '';
        this.baseScrollHeight = this.scrollHeight;
        this.value = savedValue;
    })
    .on('input.textarea', '.form-control', function(){
        var minRows = this.getAttribute('data-min-rows')|0,
            rows;
        this.rows = minRows;
        rows = Math.ceil((this.scrollHeight - this.baseScrollHeight) / 16);
        if(rows>0)
            this.rows = rows;
        else
            this.rows= 1;
        $('.direct-chat-messages').height(645-($('.box-footer').height()- 55));
    });

  $('#query-button').on('click',function(){
    $("textarea[id=query-box]").attr('rows','1'); 
        $('.direct-chat-messages').height(645-($('.box-footer').height()- 55));
        if(isIdentified){
            webChat();   
      }
        else{
            identifyUser();
      }
  });
    $('#btn-refresh').on('click',function(){
        $(".overlay").show();  
        // $(".direct-chat-messages").html(botStart+postTime()+botConcat+postGreetingLine()+', May I know your Name?'+botEnd);   
       $(".direct-chat-messages").html(botStart+postTime()+botConcat+postGreetingLine()+' '+userName+'!<br/> Welcome to ChatBot. How can I help you?'+botEnd);
        //isIdentified= false;
        $(".overlay").hide();  
        $("#query-box").attr("disabled", false);
        $("#query-button").attr("disabled", false);
        $("#btn-refresh").attr("disabled", false);
    });
    function getValueUsingClass(className){
	/* declare an checkbox array */
	var chkArray = [];
	while(chkArray.length > 0) {
    chkArray.pop();
    }
	/* look for all checkboes that have a class 'chk' attached to it and check if it was checked */
	$("."+className+":checked").each(function() {
		chkArray.push($(this).val());
	});
	
	/* we join the array separated by the comma */
	var selected;
	selected = chkArray.join(',') ;
	
	// /* check if there is selected checkboxes, by default the length is 1 as it contains one single comma */
	// if(selected.length > 0){
	// 	alert("You have selected " + selected);	
	// }else{
	// 	alert("Please at least one of the checkbox");	
    // }
    return chkArray;
}
function disableSelection(className){
	/* declare an checkbox array */
	/* look for all checkboes that have a class 'chk' attached to it and check if it was checked */
	$("."+className+":checked").each(function() {
		$(this).removeAttr('checked');
	});
}
  $('#query-box').on("keypress", function(e) {
        if (e.keyCode == 13) {
            $("textarea[id=query-box]").attr('rows','1'); 
        $('.direct-chat-messages').height(645-($('.box-footer').height()- 55));
          if(isIdentified){
                webChat();   
                botCounter = 900;
            }
            else{
                identifyUser();
            }
            return false; 
        }
});


var msgConcat ='</span></div><img class="direct-chat-img" src="img/user3-128x128.jpg" style="height:38px !important;margin-top:2px !important;" alt="Message User Image"><div class="direct-chat-text">';
var msgEnd = '</div></div>';


var botStart = '<div class="direct-chat-msg"><div class="direct-chat-info clearfix"><span class="direct-chat-name pull-left">Tech Evangelist</span><span class="direct-chat-timestamp pull-right">';
var botConcat = '</span></div><img class="direct-chat-img" src="img/user1-128x128.jpg" alt="Message User Image"><div class="direct-chat-text">';
var botEnd = '</div> </div>';

function getmsgStart(){
    return '<div class="direct-chat-msg right"> <div class="direct-chat-info clearfix"> <span class="direct-chat-name pull-right">'+userName+'</span><span class="direct-chat-timestamp pull-left">';
}
function identifyUser(){
     userName = getParameterByName('user');//toTitleCase($("#query-box").val());
     userName = toTitleCase((userName == null ? 'guest':userName));
                 $(".overlay").show(); 
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+postGreetingLine()+' '+userName+'!<br/> Welcome to ChatBot. How can I help you?'+botEnd);
                 $("#query-box").val('');
                 $(".overlay").hide();
                 $("#query-box").focus();
                isIdentified = true;
}
function toTitleCase(str)
{
    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}    
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
function webChat(){
    if($("#query-box").val().length>0){
        var userQuery = $("#query-box").val();
        $(".overlay").show(); 
    $(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+userQuery+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/chat",
            async:false,
            data: { query: userQuery, lang: "en" },
            success: function (htmlResponse) {
                if(htmlResponse){
                    if(htmlResponse.crossTab){
                        var divName = '#crosstab-'+tabCount;
                        var result = htmlResponse.data+"<br><br><div id='crosstab-"+(tabCount++)+"'></div>";
                        $(".direct-chat-messages").append(botStart+postTime()+botConcat+result+botEnd);
                        $(divName).pivot(htmlResponse.crossTab, {
                        cols: [htmlResponse.column],
                        rows: [htmlResponse.row],
                        aggregator: $.pivotUtilities.aggregators["Integer Sum"]([htmlResponse.aggregate]),
                        vals: ["live_listings"],
                        rendererName: "Table",
                        });
                    }
                    else{
                $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
                  if(htmlResponse.data.indexOf("fancy-box">0)){
                     $("a#fancy-box").fancybox({
                           'titlePosition'	: 'inside'
                      });
                  }
                    }
                   // startInterval();
                }
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
    }

}
function getReports(projectName){
        $(".overlay").show(); 
    $(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+projectName+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/ReportList",
            async:false,
            data: { project: projectName},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
}

function getClaimAnalysis(analysisType){
        $(".overlay").show(); 
    $(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+analysisType+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/ClaimAnalysis",
            async:false,
            data: { claimType: analysisType},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
}

function getReportsByMetric(APACBIMetricsEntity){
    $(".overlay").show(); 
    $(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+'Yes'+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/ReportsByMetric",
            async:false,
            data: { MetricName: APACBIMetricsEntity},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
}

function getTalentReports(projectName){
    $(".overlay").show(); 
    $(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+projectName+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/TalentReports",
            async:false,
            data: { ProjectName: projectName},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
}

function ExecuteReport(reportName){
      $(".overlay").show(); 
    $(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+reportName+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/ExecuteReport",
            async:false,
            data: { ReportName: reportName},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
                 if(htmlResponse.data.indexOf("fancy-box">0)){
                     $("a#fancy-box").fancybox({
                           'titlePosition'	: 'inside'
                      });
                  }
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
}

function getCubeInformation(cubeName){
    $(".overlay").show(); 
    $(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+cubeName+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/CubeInformation",
            async:false,
            data: { CubeName: cubeName},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
                 if(htmlResponse.data.indexOf("fancy-box">0)){
                     $("a#fancy-box").fancybox({
                           'titlePosition'	: 'inside'
                      });
                  }
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
}
function getPremiumAnalysis(analysisType){
        $(".overlay").show(); 
    $(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+analysisType+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/PermiumAnalysis",
            async:false,
            data: { premiumType: analysisType},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
}
function selectPeriodPrompt(){
           $(".overlay").show(); 
    //$(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+projectName+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/PromptAnalysis",
            async:false,
            data: { promptType: 3, promptName:'Period'},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
    }

    function runReport(report){
        window.open(report,'_blank'); 
}
    var periodArray = [];
    var BusinessArray = [];
    var RegionArray = [];
    function setPeriodArray(className){
        while(periodArray.length > 0) {
    periodArray.pop();
    }
     periodArray = getValueUsingClass(className);
     //disableSelection(className);
     console.log('periods - '+periodArray);
    }

        function setBusinessArray(className){
                while(BusinessArray.length > 0) {
    BusinessArray.pop();
    }
     BusinessArray = getValueUsingClass(className);
     //disableSelection(className);
     console.log('Business - '+BusinessArray);
    }

        function setRegionArray(className){
             while(RegionArray.length > 0) {
    RegionArray.pop();
    }
     RegionArray = getValueUsingClass(className);
    // disableSelection(className);
     console.log('Region - '+RegionArray);
    }
    
    function selectBusinessPrompt(previousPromptClass){
        //document.getElementById("region-prompt").disabled = true;
        $("input#region-prompt").attr("disabled", true);
       
    setRegionArray(previousPromptClass);
           $(".overlay").show(); 
    //$(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+projectName+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/PromptAnalysis",
            async:false,
            data: { promptType: 1, promptName:'Business'},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
    }

function generateAnalysis(previousPromptClass){
    //document.getElementById("business-prompt").disabled = true; 
    $("input#business-prompt").attr("disabled", true);
    setBusinessArray(previousPromptClass);
           $(".overlay").show(); 
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/GenerateAnalysis",
            async:false,
            data: { period: periodArray, business:BusinessArray, region:RegionArray},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
    }

    function runReport(report){
        window.open(report,'_blank'); 
}

function selectRegionPrompt(previousPromptClass){
    //document.getElementById("period-prompt").disabled = true; 
    $("input#period-prompt").attr("disabled", true);
    setPeriodArray(previousPromptClass);
           $(".overlay").show(); 
    //$(".direct-chat-messages").append(getmsgStart()+postTime()+msgConcat+projectName+msgEnd);
    $("#query-box").val('');
    $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $.ajax({
            type: "POST",
            url: "http://inggned317hyx1:3978/api/PromptAnalysis",
            async:false,
            data: { promptType: 2, promptName:'Region'},
            success: function (htmlResponse) {
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+htmlResponse.data+botEnd);
            },
            error: function (err) {
                console.log(err);
                 $(".direct-chat-messages").append(botStart+postTime()+botConcat+'Oops, I am not able to connect with Bot Server. Please check your connectivity.'+botEnd);
            }
        });
         $(".direct-chat-messages").scrollTop($(".direct-chat-messages")[0].scrollHeight);  
     $(".overlay").hide();
     $("#query-box").focus();
    }

    function runReport(report){
        window.open(report,'_blank'); 
}
function postTime(){
var date = new Date();
return date.toDateString() +' '+ date.toLocaleTimeString();
}

function postGreetingLine(){
    var today = new Date()
var curHr = today.getHours()
    if (curHr < 12) {
        return 'Good Morning'
    } else if (curHr < 18) {
        return 'Good Afternoon'
    } else {
        return 'Good Evening'
    }
}