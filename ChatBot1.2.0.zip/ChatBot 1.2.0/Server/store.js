var Promise = require('bluebird');

var request = require('request-promise');
var querystring = require('querystring');
var http = require('http');

//var mongo = require('./mongo');
var MongoClient = require('mongodb').MongoClient;
//var dbPath = 'mongodb://localhost:27017/cad';
var dbPath = 'mongodb://localhost:27017/APACDemo';


// Get ProjectList
function getProjectList(){
    return new Promise(function(resolve, reject) {
        var projects = [];
        var extServerOptions = {
        host: 'localhost',
        port:80,
        headers: {
            'Content-Type': 'application/json'
        },
        path: '/MicrostrategyMVC/metadata/GetProjectList?ProjectKey=0',
        method: 'GET'
        };
        var responseString='';
        http.request(extServerOptions, function (res) {
        res.on('data', function(data) {
        responseString += data;
        });
        res.on('end', function() {
        var responseObject = JSON.parse(responseString);
        responseObject.forEach(function(val){
        projects.push(val.IS_PROJ_NAME);
        });
        resolve(projects);
        });
    }).end();
  });
}
//Get ReportList
function getReportList(projectName){
    return new Promise(function(resolve, reject) {
        var reports = [];
        var extServerOptions = {
        host: 'localhost',
        port:80,
        headers: {
            'Content-Type': 'application/json'
        },
        path: '/MicrostrategyMVC/metadata/GetReportList?ProjectName='+projectName,
        method: 'GET'
        };
        var responseString='';
        http.request(extServerOptions, function (res) {
            res.on('data', function(data) {
            responseString += data;
        });
        res.on('end', function() {
            var responseObject = JSON.parse(responseString);
            responseObject.forEach(function(val){
            //reports.push(val.IS_DOC_NAME);
            reports.push({'ReportName':val.IS_DOC_NAME,
            'ReportGUID':val.IS_DOC_ID});
            });
            resolve(reports);
            });
        }).end();
    });
}

function getPromptArray(PromptType){
    return new Promise(function(resolve, reject) {
      MongoClient.connect(dbPath, function(err, db) {
        if (err) {
          reject(err);  
        } else {
          resolve(db);
        }        
      })
    }).then(function(db) {
      return new Promise(function(resolve, reject) {
        var collection = db.collection('arap');
        if(PromptType == 1)
       {   
            collection.distinct("Business",function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
        else if(PromptType == 2)
       {   
            collection.distinct("Region",function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
         else if(PromptType == 3)
       {   
            collection.aggregate([{"$group":{"_id":{period:"$Period",periodid:"$PeriodID"}}},{$sort:{"_id.periodid":-1}},{$limit:12}]).toArray(function(err, items) {
            //collection.distinct("Period",function(err, items) {
            if (err) {
                reject(err);
            } else {
                //resolve(items.sort((a,b) => a>b).slice(items.length-10,items.length));
                var result = [];
                items.forEach(function(item){
                    //if(item.indexOf('17') > 0){
                        result.push(item._id.period);
                  //  }
                });
                resolve(result);
            }          
            });
       }
          });
    });
    }
//Get Premium Analytics for single dimension
function getPremiumAnalytics(Dimensions){
    return new Promise(function(resolve, reject) {
        var output = []; 
        var extServerOptions = {
        host: 'localhost',
        port:80,
        headers: {
            'Content-Type': 'application/json'  
        },
        //below path yet to be created as web API, it takes one dimension as argument
        path: '/MicrostrategyMVC/Warehouse/GetPremiumByDimension?Dimension='+Dimensions,
        method: 'GET'
        };
        var responseString='';
        http.request(extServerOptions, function (res) {
            res.on('data', function(data) {
            responseString += data;
        });
        
        res.on('end', function() {
            var responseObject = JSON.parse(responseString);
            responseObject.forEach(function(val){
            output.push({'Header':val.Header,
            'Value':parseInt(val.Value)}); 
            });
            resolve(output);
            });
        }).end();
    });
}

function aggregateFinanceData(regionsEntity,busniessEntity,periodEntity,metricName){
     return new Promise(function(resolve, reject) {
      MongoClient.connect(dbPath, function(err, db) {
        if (err) {
          reject(err);  
        } else {
          resolve(db);
        }        
      })
    }).then(function(db) {
      return new Promise(function(resolve, reject) {
        var collection = db.collection('arap');
        if(regionsEntity !='' && busniessEntity !='' && periodEntity != '')
       {     
            
            collection.aggregate([{$match:{$and:[{Region:{$in:[regionsEntity]}},{Business:{$in:[busniessEntity]}},{Period:{$in:[periodEntity]}}]}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
    else if(regionsEntity !='' && periodEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Region:{$in:[regionsEntity]}},{Period:{$in:[periodEntity]}}]}},{$group:{_id:{region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
            else if(busniessEntity !='' && periodEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Business:{$in:[busniessEntity]}},{Period:{$in:[periodEntity]}}]}},{$group:{_id:{business:"$Business",period:"$Period" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
         else if(periodEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Period:{$in:[periodEntity]}}]}},{$group:{_id:{period:"$Period" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
         else if(busniessEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Business:{$in:[busniessEntity]}}]}},{$group:{_id:{period:"$Business" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
         else if(regionsEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Region:{$in:[regionsEntity]}}]}},{$group:{_id:{period:"$Region" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
      });
    });
    // return new Promise(function(resolve, reject) {
    //     var output = []; 
    //     var extServerOptions = {
    //     host: 'localhost',
    //     port:80,
    //     headers: {
    //         'Content-Type': 'application/json'
    //     },
    //     //below path yet to be created as web API, it takes one dimension as argument
    //     path: '/MicrostrategyMVC/Warehouse/GetFinanceMetric?GroupByClause='+encodeURIComponent(GroupByClause)+'&Filter='+encodeURIComponent(Filter)+'&Condition='+encodeURIComponent(Condition),
    //     method: 'GET'
    //     };
    //     var responseString='';
    //     http.request(extServerOptions, function (res) {
    //         res.on('data', function(data) {
    //         responseString += data;
    //     });
    //     res.on('end', function() {
    //         var responseObject = JSON.parse(responseString);
    //         responseObject.forEach(function(val){
    //          output.push({'Bus_Member':val.Bus_Member,
    //         'Geo_Member':val.Geo_Member,
    //         'CYR':val.CYR,
    //         'TOR':val.TOR
    //     }); 
    //         });
    //         resolve(output);
    //         });
    //     }).end();
    // });
}

function getFinanceData(regionsEntity,busniessEntity,periodEntity,metricName){
     return new Promise(function(resolve, reject) {
      MongoClient.connect(dbPath, function(err, db) {
        if (err) {
          reject(err);  
        } else {
          resolve(db);
        }        
      })
    }).then(function(db) {
      return new Promise(function(resolve, reject) {
        var collection = db.collection('arap');
        if(regionsEntity !='' && busniessEntity !='' && periodEntity != '')
       {     
            collection.aggregate([{$match:{$and:[{Region:{$in:[regionsEntity]}},{Business:{$in:[busniessEntity]}},{Period:{$in:[periodEntity]}}]}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
    else if(regionsEntity !='' && periodEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Region:{$in:[regionsEntity]}},{Period:{$in:[periodEntity]}}]}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}},{ $sort : { "_id.business": 1 }}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
            else if(busniessEntity !='' && periodEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Business:{$in:[busniessEntity]}},{Period:{$in:[periodEntity]}}]}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}},{ $sort : { "_id.region": 1 }}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
         else if(periodEntity!= '')
       {     
           collection.aggregate([{$match:{Period:{$in:[periodEntity]}}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}},{$sort:{"_id.business":-1}}]).toArray(function(err,items){
           // collection.aggregate([{$match:{Period:{$in:[periodEntity]}}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
         else if(busniessEntity!= '')
       {     
            collection.aggregate([{$match:{Business:{$in:[busniessEntity]}}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period",periodid:"$PeriodID" },AR:{$sum:"$ARv"}}},{ $sort : { "_id.periodid": -1 }},{$limit:48}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
          else if(regionsEntity!= '')
       {     
            collection.aggregate([{$match:{Region:{$in:[regionsEntity]}}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period",periodid:"$PeriodID" },AR:{$sum:"$ARv"}}},{ $sort : { "_id.periodid": -1 }},{$limit:60}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
      });
    });
}

function getFinanceDataWithMultiplePrompts(regionsEntity,busniessEntity,periodEntity,metricName){
     return new Promise(function(resolve, reject) {
      MongoClient.connect(dbPath, function(err, db) {
        if (err) {
          reject(err);  
        } else {
          resolve(db);
        }        
      })
    }).then(function(db) {
      return new Promise(function(resolve, reject) {
        var collection = db.collection('arap');
        if(regionsEntity !='' && busniessEntity !='' && periodEntity != '')
       {     
            collection.aggregate([{$match:{$and:[{Region:{$in:regionsEntity}},{Business:{$in:busniessEntity}},{Period:{$in:periodEntity}}]}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
    else if(regionsEntity !='' && periodEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Region:{$in:regionsEntity}},{Period:{$in:periodEntity}}]}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}},{ $sort : { "_id.business": 1 }}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
            else if(busniessEntity !='' && periodEntity!= '')
       {     
            collection.aggregate([{$match:{$and:[{Business:{$in:busniessEntity}},{Period:{$in:periodEntity}}]}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}},{ $sort : { "_id.region": 1 }}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
         else if(periodEntity!= '')
       {     
            collection.aggregate([{$match:{Period:{$in:periodEntity}}},{$group:{_id:{business:"$Business",region:"$Region",period:"$Period" },AR:{$sum:"$ARv"}}}]).toArray(function(err, items) {
            if (err) {
                reject(err);
            } else {
                resolve(items);
            }          
            });
       }
      });
    });
}


//Get Claims Analytics for single dimension
function getClaimsAnalytics(Dimensions){
    return new Promise(function(resolve, reject) {
        var output = []; 
        var extServerOptions = {
        host: 'localhost',
        port:80,
        headers: {
            'Content-Type': 'application/json'
        },
        //below path yet to be created as web API, it takes one dimension as argument
        path: '/MicrostrategyMVC/Warehouse/GetClaimsByDimension?Dimension='+Dimensions,
        method: 'GET'
        };
        var responseString='';
        http.request(extServerOptions, function (res) {
            res.on('data', function(data) {
            responseString += data;
        });
        res.on('end', function() {
            var responseObject = JSON.parse(responseString);
            responseObject.forEach(function(val){
            output.push({'Header':val.Header,
            'Value':parseInt(val.Value)}); 
            //reports.push(val.AggregatedClaims); //'AggregatedClaims'' will be replaced by metric name returned by query
            });
            resolve(output);
            });
        }).end();
    });
}
function getReportListByMetric(MetricName){
return new Promise(function(resolve, reject) {
        var reports = [];
        var extServerOptions = {
        host: 'localhost',
        port:80,
        headers: {
            'Content-Type': 'application/json'
        },
        path: '/MicrostrategyMVC/metadata/GetReportListByMetric?CountType='+MetricName,
        method: 'GET'
        };
        var responseString='';
        http.request(extServerOptions, function (res) {
            res.on('data', function(data) {
            responseString += data;
        });
        res.on('end', function() {
            var responseObject = JSON.parse(responseString);
            responseObject.forEach(function(val){
            //reports.push(val.IS_DOC_NAME);
            reports.push({'ReportName':val.IS_DOC_NAME,
            'ReportGUID':val.IS_DOC_ID});
            });
            resolve(reports);
            });
        }).end();
    });
}
function getCubeCount(countType){
   return new Promise(function(resolve, reject) {
        var output = []; 
        var extServerOptions = {
        host: 'localhost',
        port:80,
        headers: {
            'Content-Type': 'application/json'
        },
        //below path yet to be created as web API, it takes one dimension as argument
        path: '/MicrostrategyMVC/metadata/GetCubeCount?CountType='+countType,
        method: 'GET'
        };
        var responseString='';
        http.request(extServerOptions, function (res) {
            res.on('data', function(data) {
            responseString += data;
        });
        res.on('end', function() {
            var responseObject = JSON.parse(responseString);
            output.push({'Header':responseObject.Head,
            'Value':parseInt(responseObject.Count)}); 
            resolve(output);
            });
        }).end();
    }); 
}
function getReportCount(countType){
    return new Promise(function(resolve, reject) {
        var output = []; 
        var extServerOptions = {
        host: 'localhost',
        port:80,
        headers: {
            'Content-Type': 'application/json'
        },
        //below path yet to be created as web API, it takes one dimension as argument
        path: '/MicrostrategyMVC/metadata/GetReportCount?CountType='+countType,
        method: 'GET'
        };
        var responseString='';
        http.request(extServerOptions, function (res) {
            res.on('data', function(data) {
            responseString += data;
        });
        res.on('end', function() {
            var responseObject = JSON.parse(responseString);
            output.push({'Header':responseObject.Head,
            'Value':parseInt(responseObject.Count)}); 
            resolve(output);
            });
        }).end();
    });
}
function getIntent(utterance){
 return new Promise(function(resolve, reject) {
    var luisData;
      var endpoint = "https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/";
    https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/cf8ff5fd-9eea-412d-bf75-a30603972c8a?subscription-key=fc1f109c16774c518e2709e90d4bc5e3&verbose=true&timezoneOffset=330&q= 
    // var luisAppId = 'fb4b1a5d-0493-40eb-94b6-1fddfad38b20';
    var luisAppId = 'cf8ff5fd-9eea-412d-bf75-a30603972c8a';
    
    var queryParams = {
          "subscription-key": "fc1f109c16774c518e2709e90d4bc5e3",
        "timezoneOffset": "5.5",
        "verbose":  true,
        "q": utterance
    }
    
var proxiedRequest = request.defaults({'proxy': process.env.PROXY_URL});
    var luisRequest =
        endpoint + luisAppId +
        '?' + querystring.stringify(queryParams);

   proxiedRequest(luisRequest,
        function (err,
            response, body) {
            if (err){
                
            resolve(err);
            }
            else {
                luisData = JSON.parse(body);
                 //saveUtterance(luisData);
                 resolve(luisData);
            }
        })
    });
}
// mongo.arapCollection().then(function(items) {
//   console.info('The promise was fulfilled with items!', items);
// }, function(err) {
//   console.error('The promise was rejected', err, err.stack);
// });
//saveUtterance();
// function saveUtterance(result){
// //     mongo.dbo.collection("arap").find({Business:'Career'}).toArray(function(err, result) {
// //     if (err) throw err;
    
// //     db.close();
// //   });
//  new mongo(result).save(function(err,data){
// 			if (err) {
				
//             }
// 		});
// }

module.exports = {
    getIntent:function(utterance){
    return new Promise(function (resolve) {
    var result = getIntent(utterance);
             setTimeout(function () { resolve(result); }, 1000);
         });
    },
    searchProjects:function(){
    return new Promise(function (resolve) {
    var projectlist = getProjectList();
             setTimeout(function () { resolve(projectlist); }, 1000);
         });
    },
    searchReports:function(projectName){
    return new Promise(function (resolve) {
    var reportlist = getReportList(projectName);
             setTimeout(function () { resolve(reportlist); }, 1000);
         });
    },
    PremiumResponse:function(Dimensions){
    return new Promise(function (resolve) {
    var PremiumOutput = getPremiumAnalytics(Dimensions);
             setTimeout(function () { resolve(PremiumOutput); }, 1000);
         });
    },
    PromptResponse:function(PromptType){
    return new Promise(function (resolve) {
    var PromptOutput = getPromptArray(PromptType);
             setTimeout(function () { resolve(PromptOutput); }, 1000);
         });
    },
    ClaimsResponse:function(Dimensions){
    return new Promise(function (resolve) {
    var ClaimsOutput = getClaimsAnalytics(Dimensions);
             setTimeout(function () { resolve(ClaimsOutput); }, 1000);
         });
    },
    FinanceAggregateResponse:function(regionsEntity,busniessEntity,periodEntity,metricName){
    return new Promise(function (resolve) {
    var FinanceOutput = aggregateFinanceData(regionsEntity,busniessEntity,periodEntity,metricName);
             setTimeout(function () { resolve(FinanceOutput); }, 1000);
         });
    },
    FinanceResponse:function(regionsEntity,busniessEntity,periodEntity,metricName){
    return new Promise(function (resolve) {
    var FinanceOutput = getFinanceData(regionsEntity,busniessEntity,periodEntity,metricName);
             setTimeout(function () { resolve(FinanceOutput); }, 1000);
         });
    },
    FinanceResponseWithMultiplePrompts:function(regionsEntity,busniessEntity,periodEntity,metricName){
    return new Promise(function (resolve) {
    var FinanceOutput = getFinanceDataWithMultiplePrompts(regionsEntity,busniessEntity,periodEntity,metricName);
             setTimeout(function () { resolve(FinanceOutput); }, 1000);
         });
    },
    ReportCountResponse:function(countType){
    return new Promise(function (resolve) {
    var reportCount = getReportCount(countType);
             setTimeout(function () { resolve(reportCount); }, 1000);
         });
    },
        CubeCountResponse:function(countType){
    return new Promise(function (resolve) {
    var cubeCount = getCubeCount(countType);
             setTimeout(function () { resolve(cubeCount); }, 1000);
         });
    },
        ReportListByMetricResponse:function(countType){
    return new Promise(function (resolve) {
    var reportList = getReportListByMetric(countType);
             setTimeout(function () { resolve(reportList); }, 1000);
         });
    }
};