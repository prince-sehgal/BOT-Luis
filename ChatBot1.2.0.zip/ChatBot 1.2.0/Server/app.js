// This loads the environment variables from the .env file
require('dotenv-extended').load();

var restify = require('restify');
var Store = require('./store');

// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
      console.log('%s listening to %s', server.name, server.url);
});

server.use(restify.bodyParser());
server.use(function crossOrigin(req,res,next){
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    return next();
  });
var webChat = function(req, res, next) {
        Store.getIntent(req.params.query)
                .then(function (result) {
                    switch(result.topScoringIntent.intent){
                        case 'Greeting':
                         res.json({
                           
                        data: 'I can help you analyze data using <grn><bld>Narrative Science</bld></grn> (which combines <bld>AI</bld> and <bld>NLP</bld>): <br/><ul type="number"><li>Execute existing reports in Microstrategy, either through guided interaction or with specific parameters</li><li>Generate analytics from various data cubes</li><li>Generate additional insights from existing reports</li></ul>'
                        //<li>Data Mining capability on Knowledge  Fabric</li>
                    });   
                        break;
                        case 'thanks':
                         res.json({
                        data:'Happy to help.'
                    });   
                        break;
                        case 'FinanceReporting':
                      
                        break;
                        case 'thanks':
                        res.json({
                        data:'Happy to help.'
                        });   
                        break;
                    case 'RefreshReportInfo':

                    var RefreshReportEntity = result.entities[result.entities.findIndex(function(val) {
                                                                  return val.type == 'RefreshReport'
                                                                })];
                    var FinanceReportsEntity = result.entities[result.entities.findIndex(function(val) {
                                                              return val.type == 'FinanceReports'
                                                            })];
                    if(RefreshReportEntity.resolution.values[0] == 'Last report refresh'){
                        res.json({
                            data:'<bld>'+FinanceReportsEntity.resolution.values[0]+'</bld> is a monthly dashboard. It was refreshed on 1 March, 2017.'
                                });    
                    }
                    else if(RefreshReportEntity.resolution.values[0] == 'Next report refresh'){
                       res.json({
                            data:'<bld>'+FinanceReportsEntity.resolution.values[0]+'</bld> is a monthly dashboard. It will refresh on 1 April, 2017.'
                                });    
                    }
                    else if(RefreshReportEntity.resolution.values[0] == 'Report refresh frequency'){
            res.json({
                data:'Report refresh frequency for <bld>'+FinanceReportsEntity.resolution.values[0]+'</bld> is monthly.'
                    });    
                    }
                  else
                    {               
                        res.json({
                        data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                            });    
                    }   

                    break;
                    case 'DataMining':
                    var dataMiningEntity =result.entities[result.entities.findIndex(function(val) {
                                                          return val.type == 'DecisionTree'
                                                        })];
                    if(dataMiningEntity){
                        if(dataMiningEntity.entity == 'churn'){
                            var outline ='Based on the latest data submitted to data-mining team, here is the summarized verdict towards <bld>"Customer Churn Prediction"</bld>:<br/><ul type="disc"><li><bld>Prediction Model</bld></li><ul type="circle"><li>Decision Tree Classification Model</li></ul><li><bld>Narrative Verdict</bld></li><ul type="circle"><li>We have processed historical record of overall 10000 telecom customers out of which 7500 are still active.</li><li>We analyized customer churn based on following categorical values: Customer, Gender, Marital Status, Income Bracket, Household count, Customer engagement factors like (start date, expiry date, active months, dropped calls, Net Present Value etc.</li><li>Decision processing model finalized <bld><rd>28</rd></bld> customers which accounts to <bld><rd>15%</rd></bld> churn propensity.</li></ul><li><bld>Action</bld></li><ul type="circle"><li>Please take proactive actions to mitigate churn risk. Please click on below link to access the list of leads.</li></ul></ul>';
                            outline +="<a id='fancy-box'  style='position: absolute;right: 40px;' href='./img/churn.png' title='This image depicts predictions across potential customer churn from Telecom industry.'><img alt='Decision Tree Prediction' src='' style='' title=''/></a>&nbsp;";
                            // outline+= '&nbsp;<a style="position: absolute;right: 2px;bottom: 2px;" href="javascript:void(0);" onclick=runReport("http://inggned8n3yqg2/MicroStrategy/asp/Main.aspx?Server=INGGNED8N3YQG2&Project=Mercer+Marketplace+Dev&Port=0&evt=4001&src=Main.aspx.4001&visMode=0&reportViewMode=1&reportID=375AC33649C853CC1217CD990B05721C&reportSubtype=768&uid=administrator&pwd=&hiddensections=header,path,dockTop,dockLeft,footer")>++more</a>';
                            
                        res.json({
                                data:outline
                            });  
                        }
                        else
                        {               
                            res.json({
                            data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                });    
                        }       
                    }
                    else
                    {               
                        res.json({
                        data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                            });    
                    }                          
                    break;
                    case 'SurveyAnalysis':
                     var talentEntity =result.entities[result.entities.findIndex(function(val) {
                                      return val.type == 'TalentMetrics'
                                    })];
                     if(talentEntity){
                        if(talentEntity.entity == 'tier' || talentEntity.entity == 'tiers' || talentEntity.entity == 'level'){
                        res.json({
                                data:"<a id='fancy-box' href='./img/Tiers.jpg' title='This image depicts Tier wise span analysis for Mercer GTI and PM vs IC ratio for September, 2017.'><img alt='example5' src='./img/Tiers.jpg' style='width:190px;height:100px;' title='Click here to see large view'/></a>"    
                            });  
                        }
                        else if(talentEntity.entity == 'gender diversity' || talentEntity.entity == 'gender diversity ratio' || talentEntity.entity == 'male to female ratio' || talentEntity.entity == 'M:F'){
                            res.json({
                                data:"<a id='fancy-box' href='./img/gender.jpg' title='This image depicts gender diversity ratio across GTI by level 7 for September, 2017.'><img alt='example5' src='./img/gender.jpg' style='width:185px;height:100px;'  title='Click here to see large view'/></a>"
                            });  
                        }
                        else if(talentEntity.entity == 'headcount' || talentEntity.entity == 'employee headcount' || talentEntity.entity == 'employees headcount'){
                        res.json({
                                data:"<a id='fancy-box' href='./img/headcount.png' title='This image depicts Employee headcount for Mercer GTI by LOB for September, 2017.'><img alt='example5' src='./img/headcount.png' style='width:200px;height:100px;' title='Click here to see large view'/></a>"
                            });  
                        }
                        else
                        {               
                            res.json({
                            data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                });    
                        } 
                    }
                    else
                    {               
                        res.json({
                        data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                            });    
                    }         
                    break;
                        case 'BrowseProjects':

                     var domainEntity =result.entities[result.entities.findIndex(function(val) {
                                                                                      return val.type == 'Domain'
                                                                                    })];    
                            if(domainEntity){
                                    if(domainEntity.entity == 'finance'){  
                                        var projectList=['Client_Profitablity','People_Productivity'];
                                          var outline ='I have found following projects in "Enterprise Reporting" repository, you may choose any one from below list -';
                projectList.forEach(function(val,index){
                    outline += '<br/>'+(index+1)+'. <a href="javascript:void(0);" onclick=getReports("'+val+'")>'+val+'</a>';
                });
                                    res.json({
                                         data:outline
                                        });   
                                    }
                                    else  if(domainEntity.entity == 'health' || domainEntity.entity == 'h & b'){ 
                                           Store.searchProjects()
                                                .then(function (projects) {
                                                var outline ='I have found following projects in "APAC" repository, you may choose any one from below list -';
                                                projects.forEach(function(val,index){
                                                    outline += '<br/>'+(index+1)+'. <a href="javascript:void(0);" onclick=getReports("'+val+'")>'+val+'</a>';
                                                });
                                                res.json({
                                                            data:outline
                                                        });   
                                                });
                                    }
                                             else  if(domainEntity.entity == 'talent'){ 
                                                  var projectList=['Human_Resources','Learning&Development'];
                                                  var outline ='I have found following projects in "Talent" respository, you may choose any one from below list -';
                                                projectList.forEach(function(val,index){
                                                    outline += '<br/>'+(index+1)+'. <a href="javascript:void(0);" onclick=getTalentReports("'+val+'")>'+val+'</a>';
                                                });
                                                res.json({
                                                            data:outline
                                                        });   
                                    }
                                                     else{
                                    res.json({
                                         data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                        });   
                                }
                            }
                                else{
                                    res.json({
                                         data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                        });   
                                }
                    break;
                          case 'BrowseReports':
                           var Aggregation =result.entities[result.entities.findIndex(function(val) {
                                      return val.type == 'countReports'
                                    })];
                            var APACBIMetricsEntity  =result.entities[result.entities.findIndex(function(val) {
                              return val.type == 'APACBIMetrics'
                            })];

                            var cubeEntity  =result.entities[result.entities.findIndex(function(val) {
                              return val.type == 'Cube'
                            })];

                         var dimensionsEntity =result.entities[result.entities.findIndex(function(val) {
                                      return val.type == 'Dimensions'
                                    })];
                            if(APACBIMetricsEntity){
                                if(Aggregation && cubeEntity){
                                       Store.CubeCountResponse(APACBIMetricsEntity.entity)
                                            .then(function (dataset) {
                                     var outline ='Presently, there are '+dataset[0].Value+' intelligent cube[s] with name <bld>'+dataset[0].Header+'</bld> that have <bld> '+toTitleCase(APACBIMetricsEntity.entity)+'</bld> metrics.' 
                                     if(dataset[0].Value>0){
                                            outline+= "<br/>Do you want to do analysis across it?";
                                            outline += '<br/><ul><li><a href="javascript:void(0);" onclick=getCubeInformation("'+dataset[0].Header+'")>Yes</a></li>';
                                            outline += '<li><a href="javascript:void(0);">No</a></li></ul>';
                                     }
                                                res.json({
                                                        data:outline
                                                    }); 
                                            });     
                                }
                                else if(Aggregation){
                                             Store.ReportCountResponse(APACBIMetricsEntity.entity)
                                            .then(function (dataset) {
                                            var outline ='Presently, there are '+dataset[0].Value+' reports that have <bld>'+  toTitleCase(APACBIMetricsEntity.entity)+'</bld> metrics.' 
                                            outline+= "<br/>Do you want to see list of All reports?";
                                            outline += '<br/><ul><li><a href="javascript:void(0);" onclick=getReportsByMetric("'+APACBIMetricsEntity.entity+'")>Yes</a></li>';
                                            outline += '<li><a href="javascript:void(0);">No</a></li></ul>';
                                                res.json({
                                            data:outline
                                        });    
                                    });
                                }
                                else
                                {
                                    
                                   res.json({
                                    data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                        });    
                                }
                            }
                            else
                            {
                                
                                res.json({
                                data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                    });    
                            }
                        break;
                          case 'HealthDataAnalysis':
                          var regionsEntity = result.entities[result.entities.findIndex(function(val) {
                                      return val.type == 'FinanceRegions'
                                    })];

                            var periodEntity = result.entities[result.entities.findIndex(function(val) {
                              return val.type == 'Period'
                            })];
                                
                                    var busniessEntity = result.entities[result.entities.findIndex(function(val) {
                              return val.type == 'Business'
                            })];
                        var dimensionEntity = result.entities[result.entities.findIndex(function(val) {
                              return val.type == 'Dimensions'
                            })]; 

                            var filterEntity =result.entities[result.entities.findIndex(function(val) {
                              return val.type == 'filter'
                            })];
                            var metricsEntity =result.entities[result.entities.findIndex(function(val) {
                              return val.type == 'FinanceMetrics'
                            })];
                        if(metricsEntity){
                            var metricName = (metricsEntity.entity =='accounts receivable' || metricsEntity.entity =='ar' || metricsEntity.entity == 'receivable' || metricsEntity.entity == 'ar outstanding') ? 'AR_Outstanding':'';
  var metricShortName = (metricsEntity.entity =='accounts receivable' || metricsEntity.entity =='ar' || metricsEntity.entity == 'receivable' || metricsEntity.entity == 'ar outstanding') ? 'AR Outstanding':'';
                            if(regionsEntity && busniessEntity && periodEntity)
                            {
                                    Store.FinanceResponse(regionsEntity.resolution.values[0],busniessEntity.resolution.values[0],periodEntity.resolution.values[0],metricName)
                                      .then(function (financeData) {
                                                        var outline ='This analysis measures <bld>AR By Region/Business of the Relationship Manager | As of '+periodEntity.resolution.values[0]+'</bld>. The <bld>'+metricName+'</bld> values will be on currency USD at 2017 MMC Budget Rate (000\'s). Value of <bld>'+metricsEntity.entity+'</bld> for Business - <bld>'+busniessEntity.resolution.values[0]+'</bld> and Region - <bld>'+regionsEntity.resolution.values[0]+'</bld> is ';
                                                        financeData.forEach(function(item){
                                                            outline +=getColorCode((item.AR/1000).toFixed(0));
                                                        });
                                                        res.json({
                                                                data:outline
                                                                });   
                                                            });
                            }
                            else if(periodEntity && regionsEntity)
                            {
                                  Store.FinanceAggregateResponse(regionsEntity.resolution.values[0],'',periodEntity.resolution.values[0],metricName)
                                      .then(function (AggregatedData) {
                                          Store.FinanceResponse(regionsEntity.resolution.values[0],'',periodEntity.resolution.values[0],metricName)
                                      .then(function (financeData) {
                                                      var outline ='This analysis measures <bld>AR By Region/Business of the Relationship Manager | As of '+periodEntity.resolution.values[0]+'</bld>. The <bld>'+metricName+'</bld> values will be on currency USD at 2017 MMC Budget Rate (000\'s). Value of <bld>'+metricShortName+'</bld> for Region - <bld>'+regionsEntity.resolution.values[0]+'</bld> and for all Business is ';
                                                        AggregatedData.forEach(function(item){
                                                            outline +=getColorCode((item.AR/1000).toFixed(0));
                                                        });
                                                         outline +='<br><br><table class="table table-bordered" style="background-color:white;"><tbody><tr><th>Business</th><th style="width: 135px">'+metricShortName +'</th></tr>';
                                                        financeData.forEach(function(item){
                                                        outline +='<tr><td>'+item._id.business+'</td><td align=right>'+getFormattedCurrency((item.AR/1000).toFixed(0))+'</td></tr>';
                                                        });
                                                        outline += '</tbody> </table>';
                                                        res.json({
                                                                data:outline
                                                                });   
                                      });
                                                            });
                            }
                            else if(periodEntity && busniessEntity)
                            {
                                 Store.FinanceAggregateResponse('',busniessEntity.resolution.values[0],periodEntity.resolution.values[0],metricName)
                                      .then(function (AggregatedData) {
                                             Store.FinanceResponse('',busniessEntity.resolution.values[0],periodEntity.resolution.values[0],metricName)
                                      .then(function (financeData) {
                                                        var outline ='This analysis measures <bld>AR By Region/Business of the Relationship Manager | As of '+periodEntity.resolution.values[0]+'</bld>. The <bld>'+metricName+'</bld> values will be on currency USD at 2017 MMC Budget Rate (000\'s). Value of <bld>'+metricsEntity.entity+'</bld> for Business - <bld>'+busniessEntity.resolution.values[0]+'</bld> and for all Region is ';
                                                        AggregatedData.forEach(function(item){
                                                            outline +=getColorCode((item.AR/1000).toFixed(0));
                                                        });
                                                            outline +='<br><br><table class="table table-bordered" style="background-color:white;"><tbody><tr><th>Region</th><th style="width: 135px">'+metricShortName +'</th></tr>';
                                                        financeData.forEach(function(item){
                                                        outline +='<tr><td>'+item._id.region+'</td><td align=right>'+getFormattedCurrency((item.AR/1000).toFixed(0))+'</td></tr>';
                                                        });
                                                        res.json({
                                                                data:outline
                                                                });   
                                                            });
                                      });
                            }
                                else if(periodEntity)
                            {
                               // (periodEntity.resolution.values[0]+' '+metricName);
                                   Store.FinanceAggregateResponse('','',periodEntity.resolution.values[0],metricName)
                                      .then(function (AggregatedData) {
                                            Store.FinanceResponse('','',periodEntity.resolution.values[0],metricName)
                                      .then(function (financeData) {
                                                  var outline ='This analysis measures <bld>AR By Region/Business of the Relationship Manager | As of '+periodEntity.resolution.values[0]+'</bld>. The <bld>'+metricName+'</bld> values will be on currency USD at 2017 MMC Budget Rate (000\'s). Value of <bld>'+metricsEntity.entity+'</bld> for all Business and all Region is ';
                                                  var crossTabArray = [];
                                                        AggregatedData.forEach(function(item){
                                                            outline +=getColorCode((item.AR/1000).toFixed(0));
                                                        });
                                                        financeData.forEach(function(item){
                                                           crossTabArray.push({
                                                               Business: item._id.business,
                                                               Region: item._id.region,
                                                               ar: (item.AR/1000).toFixed(0)
                                                           });
                                                        });
                                                        res.json({
                                                                data:outline,
                                                                crossTab: crossTabArray,
                                                                column:'Region',
                                                                row:'Business',
                                                                aggregate:'ar'
                                                                });   
                                                            });
                                      });
                            }
                                     else if(busniessEntity)
                            {
                               // (periodEntity.resolution.values[0]+' '+metricName);
                                   Store.FinanceAggregateResponse('',busniessEntity.resolution.values[0],'',metricName)
                                      .then(function (AggregatedData) {
                                            Store.FinanceResponse('',busniessEntity.resolution.values[0],'',metricName)
                                      .then(function (financeData) {
                                                  var outline ='This analysis measures <bld>AR By Business of the Relationship Manager | As of '+busniessEntity.resolution.values[0]+'</bld>. The <bld>'+metricName+'</bld> values will be on currency USD at 2017 MMC Budget Rate (000\'s). Value of <bld>'+metricsEntity.entity+'</bld> for all Region and all Period is ';
                                                  var crossTabArray = [];
                                                        AggregatedData.forEach(function(item){
                                                            outline +=getColorCode((item.AR/1000).toFixed(0));
                                                        });
                                                        financeData.forEach(function(item){
                                                           crossTabArray.push({
                                                               Period: item._id.period,
                                                               Region: item._id.region,
                                                               ar: (item.AR/1000).toFixed(0)
                                                           });
                                                        });
                                                        res.json({
                                                                data:outline,
                                                                crossTab: crossTabArray,
                                                                column:'Region',
                                                                row:'Period',
                                                                aggregate:'ar'
                                                                });   
                                                            });
                                      });
                            }
                                      else if(regionsEntity)
                            {
                               // (periodEntity.resolution.values[0]+' '+metricName);
                                   Store.FinanceAggregateResponse(regionsEntity.resolution.values[0],'','',metricName)
                                      .then(function (AggregatedData) {
                                            Store.FinanceResponse(regionsEntity.resolution.values[0],'','',metricName)
                                      .then(function (financeData) {
                                                  var outline ='This analysis measures <bld>AR By Region of the Relationship Manager | As of '+regionsEntity.resolution.values[0]+'</bld>. The <bld>'+metricName+'</bld> values will be on currency USD at 2017 MMC Budget Rate (000\'s). Value of <bld>'+metricsEntity.entity+'</bld> for all Business and all Period is ';
                                                  var crossTabArray = [];
                                                        AggregatedData.forEach(function(item){
                                                            outline +=getColorCode((item.AR/1000).toFixed(0));
                                                        });
                                                        financeData.forEach(function(item){
                                                           crossTabArray.push({
                                                               Period: item._id.period,
                                                               Business: item._id.business,
                                                               ar: (item.AR/1000).toFixed(0)
                                                           });
                                                        });
                                                        res.json({
                                                                data:outline,
                                                                crossTab: crossTabArray,
                                                                column:'Business',
                                                                row:'Period',
                                                                aggregate:'ar'
                                                                });   
                                                            });
                                      });
                            }
                                else
                                {               
                                    res.json({
                                    data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                        });    
                                }
                             }
                                else
                                {               
                                    res.json({
                                    data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                        });    
                                }
                        break;
                        case 'SuggestAPACDimensions':
                          var FinanceMetricsEntity =result.entities[result.entities.findIndex(function(val) {
                                      return val.type == 'FinanceMetrics'
                                    })];
                                if(FinanceMetricsEntity){
                                     var outline ='Based on the data available in Enterprise Reporting development environment for data-mining i.e. upto March 2017, here is the summarized verdict towards <bld>"Seasonal Prediction"</bld>:<br/><ul type="disc"><li><bld>Prediction Model</bld></li><ul type="circle"><li>Time Series Predictive Model</li></ul><li><bld>Narrative Verdict</bld></li><ul type="circle"><li>We have processed historical record of 3 years (2015, 2016, 2017) for business and geographies.</li><li>We analyized <bld>Current Year Revenue</bld> for business (Health, Career, Global Business Solutions and Others) and geographies (Europac, Growth Markets and North America).</li><li>Timeline forecast predicted CYR trending for next <bld>10</bld> months.</li></ul><li><bld>Conclusion</bld></li><ul type="circle"><li>Prediction shows a continuous trend ranging from <bld><grn>104.1%</grn></bld> (for Apr 2017) to <bld><rd>94.3%</rd></bld> (for Aug 2017).</li></ul></ul>';
                            outline +="<a id='fancy-box'  style='position: absolute;right:40px;' href='./img/prediction.png' title='This image depicts <bld>Seasonal Prediction</bld> for <bld>Current Year Revenue</bld>.'><img alt='Seasonal Prediction' src='' title=''/></a>&nbsp;";
                            // outline+= '&nbsp;<a style="position: absolute;right: 2px;bottom: 2px;" href="javascript:void(0);" onclick=runReport("http://inggned8n3yqg2/MicroStrategy/asp/Main.aspx?evt=3186&src=Main.aspx.3186&subscriptionID=5FEEB55C4E646F1A8450F7B7DBF8BCB8&Server=INGGNED8N3YQG2&Project=Mercer%20Marketplace%20Dev&Port=0&share=1&uid=administrator&pwd=&hiddensections=header,path,dockTop,footer")>++more</a>';
                                        res.json({
                                        data:outline
                                    });  
                                }
                                else{
                                      res.json({
                                    data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                        });  
                                }
                        break;
                        default:
                                    res.json({
                                    data:'As of now, I am not trained to cater this request. Please reach out to <a href="mailto:pankaj.rautela@mercer.com">administrator</a>'
                                        });  
                        break;
                    }
                });
     
}

var reportList = function(req, res, next) {
                
                if(req.params.project == 'People_Productivity'){
                    var outline ='As per your selection, in <bld>'+req.params.project+'</bld> project I have found below reports.<br/>You may execute any report by clicking report-name.';
                    outline += '<br/>1. <a href="javascript:void(0);" onclick=runReport("https://mercer.cloud.microstrategy.com:1443/MicroStrategy/servlet/mstrWeb?Server=C333LIWD03NA01&Project=People+Productivity&Port=0&evt=2048001&src=mstrWeb.2048001&visMode=0&currentViewMedia=2&documentID=6543312846652B1B671E488BE5CF9D3D")>Monthly Time Entry Compliance Dashboard</a>';

                       outline += '<br/>2. <a href="javascript:void(0);" onclick=runReport("https://mercer.cloud.microstrategy.com:1443/MicroStrategy/servlet/mstrWeb?Server=C333LIWD03NA01&Project=People+Productivity&Port=0&evt=2048001&src=mstrWeb.2048001&visMode=0&currentViewMedia=2&documentID=9A657DB84474F4FCE0A4F7A1CD74D9C8")>IT Monthly Time Entry Compliance Dashboard</a>';
                        res.json({
                        data:outline
                    }); 
                     
                }
                else if(req.params.project == 'Client_Profitablity'){
                    var outline ='As per your selection, in <bld>'+req.params.project+'</bld> project I have found below reports.<br/>You may execute any report by clicking report-name.';
                      outline += '<br/>1. <a href="javascript:void(0);" onclick=runReport("https://mercer.cloud.microstrategy.com:1443/MicroStrategy/servlet/mstrWeb?Server=C333LIWD03NA01&Project=Sales+Operations&Port=0&evt=2048001&src=mstrWeb.2048001&visMode=0&currentViewMedia=2&documentID=2210D87C43983ECCCE53DDA9B26CDE81")>Leadership Sales Dashboard</a>';
                      outline += '<br/>2. <a href="javascript:void(0);" onclick=runReport("https://mercer.cloud.microstrategy.com:6443/MicroStrategy/servlet/mstrWeb?Server=C333LIWD03NA01&Project=Client+Profitability&Port=0&evt=2048001&src=mstrWeb.2048001&visMode=0&currentViewMedia=2&documentID=9DC8B0E74CFBFD06DF28BBB2F4360622")>AR & WIP Dashboard</a>';
                      outline += '<br/>3. <a href="javascript:void(0);" onclick="selectPeriodPrompt()">AR Daily Dashboard</a>';
                      res.json({
                        data:outline
                    });   
                }
                else{
                    Store.searchReports(req.params.project)
                    .then(function (reports) {
                        var outline ='As per your selection, in <bld>'+req.params.project+'</bld> project I have found below reports.<br/>You may execute any report by clicking report-name.';
                        reports.forEach(function(val,index){
                            outline += '<br/>'+(index+1)+'. <a href="javascript:void(0);" onclick=runReport("http://aumel13as26v/microstrategy/asp/Main.aspx?Server=-Hvj-9FOGThHtL_gNFK0kvldLjnU%3D&Project=APAC_CAD_Analytics%28China%29&Port=-P4NgwgBR5B0OtjIg&evt=4001&src=Main.aspx.4001&visMode=0&reportViewMode=2&reportID='+val.ReportGUID+'&reportSubtype=769&uid=administrator&pwd=madmin&hiddensections=header,path,dockTop,dockLeft,footer")>'+val.ReportName+'</a>';
                        });  
                        res.json({
                            data:outline
                        });   
                    });
                }
}


var ReportsByMetric = function(req, res, next) {
       Store.ReportListByMetricResponse(req.params.MetricName)
        .then(function (reports) {
                var outline ='As per your selection, for <bld>'+toTitleCase(req.params.MetricName)+'</bld> metric. I have found below reports.<br/>You may execute any report by clicking report-name.';
                reports.forEach(function(val,index){
                    outline += '<br/>'+(index+1)+'. <a href="javascript:void(0);" onclick=runReport("http://aumel13as26v/microstrategy/asp/Main.aspx?Server=-Hvj-9FOGThHtL_gNFK0kvldLjnU%3D&Project=APAC_CAD_Analytics%28China%29&Port=-P4NgwgBR5B0OtjIg&evt=4001&src=Main.aspx.4001&visMode=0&reportViewMode=2&reportID='+val.ReportGUID+'&reportSubtype=769&uid=administrator&pwd=madmin&hiddensections=header,path,dockTop,dockLeft,footer")>'+val.ReportName+'</a>';
                   
                });
                  res.json({
                            data:outline
                        });   
                });
}

var TalentReports = function(req, res, next) {
       var outline ='As per your selection, in <bld>'+req.params.ProjectName+'</bld> project, I have found below reports.<br/>You may execute any report by clicking report-name.';
            if(req.params.ProjectName == 'Human_Resources'){
                    outline += '<br/><ul><li><a href="javascript:void(0);" onclick=ExecuteReport("Gender_diversity_ratio")>Gender Diversity Ratio</a></li>';
                    outline += '<li><a href="javascript:void(0);" onclick=ExecuteReport("employee_headcount")>Employee Headcount</a></li>';
                    outline += '<li><a href="javascript:void(0);" onclick=ExecuteReport("tiers_analysis")>Tiers Analysis</a></li></ul>';
                }
                else if(req.params.ProjectName == 'Learning&Development'){
 outline += '<br/><ul><li><a href="javascript:void(0);" onclick=ExecuteReport("MercerOS_Charter")>On-Demand MercerOS Charter</a></li></ul>';
                }
                  res.json({
                            data:outline
                        });   
 }

var CubeInformation = function(req, res, next) {
    //req.params.CubeName 
    var outline = '<bld>Narrative Summary</bld> of <bld>'+req.params.CubeName+'</bld> cube.<ul><li>This Cube contains two object prompts (ClaimsDimsOP, ClaimsMetricsOP) to facilitate on the fly creation of report template.</li><li>This Cube have information about "Paid Claims" and associated "Number of Claimants" metrics at following level.<ul type="circle"><li>Country-CHN</li><li>Entity</li><li>Group Name(U)</li><li>Mercer Product Class 1</li><li>Mercer Product Class 2</li><li>Policy</li><li>Policy-Period</li></ul></li>';

    outline+= '&nbsp;<a style="position: absolute;right: 2px;bottom: 2px;" target="_blank" href="http://aumel13as26v/MicroStrategy/asp/Main.aspx?evt=4001&src=Main.aspx.4001&visMode=0&reportViewMode=1&reportID=298454CE47399499627869B252F23DDE&reportSubtype=768&Server=AUMEL13AS26V&Project=APAC_CAD_Analytics(China)&Port=0&objectsPromptAnswers=4ADB85AD4732080C3646CD847975B1D3~12~[Country-CHN]%1BD051472444C75396ACDF2695CCC975E7~12~[Entity]%1B5EB70E2448C3154372DB53A80A3CA879~12~[Group Name(U)]%1BD159CC4F46FAF7DC1A260F873AD58117~12~[Mercer Product Class 1]%1BFCB5D7E243BF5C0724C38F9B54554D3B~12~[Mercer Product Class 2]%1BA44E4F3D4160C6E8A89EC3A504A5CC3F~12~[Policy]%1B063B4F654B6CCA8DF98623A98435A86E~12~[Policy-Period]%5E9958C203400827B23FA623AC400A712D~4~[#Claimants]%1B950D383D41D2AC0EC66F939D5BC37861~4~[Paid Claims]&uid=pankaj&pwd=pankaj1&hiddensections=header,path,dockTop,dockLeft,footer">++more</a>'
        res.json({
                data:outline
            });   
 }

var ExecuteReport = function(req, res, next) {
    var outline = '&nbsp;';
     if(req.params.ReportName == 'tiers_analysis'){
         outline ="<a id='fancy-box' href='./img/Tiers.jpg' title='This image depicts Tier wise span analysis for Mercer GTI and PM vs IC ratio for September, 2017.'><img alt='example5' src='./img/Tiers.jpg' style='width:190px;height:100px;' title='Click here to see large view'/></a>";
     }
        else if(req.params.ReportName == 'Gender_diversity_ratio'){
         outline ="<a id='fancy-box' href='./img/gender.jpg' title='This image depicts gender diversity ratio across GTI by level 7 for September, 2017.'><img alt='example5' src='./img/gender.jpg' style='width:185px;height:100px;'  title='Click here to see large view'/></a>";
     }
          else if(req.params.ReportName == 'employee_headcount'){  
         outline ="<a id='fancy-box' href='./img/headcount.png' title='This image depicts Employee headcount for Mercer GTI by LOB for September, 2017.'><img alt='example5' src='./img/headcount.png' style='width:200px;height:100px;' title='Click here to see large view'/></a>";
     }
             else if(req.params.ReportName == 'MercerOS_Charter'){
         outline ="<a id='fancy-box' href='./img/MercerOSCharter.png' title='This image depicts MercerOS status Charter for March, 2017. This is available on demand.'><img alt='example5' src='./img/MercerOSCharter.png' style='width:200px;height:100px;' title='Click here to see large view'/></a>";
     }
                  res.json({
                            data:outline
                        });   
 }

var promptAnalysis = function(req, res, next) {
       Store.PromptResponse(req.params.promptType)
                       .then(function (array) {
                           var outline ='Please select prompt answer for <bld>';
                            if(req.params.promptType == 3){
                        outline += '<span class="badge bg-orange">'+req.params.promptName+'</span>';
                            }
                    else if(req.params.promptType == 2){
                        outline += '<span class="badge bg-purple">'+req.params.promptName+'</span>';
                            }
                    else if(req.params.promptType == 1){
                        outline += '<span class="badge bg-blue">'+req.params.promptName+'</span>';
                            }
                          outline +='</bld> prompt -<br><br><table class="table table-bordered" style="background-color:white;"><tbody>';
                          array.forEach(function(item){
                              //<label><input type="checkbox" name="checkbox" value="value">Text</label>
                            outline+='<tr><td width="130px"><label><input type="checkbox" value="'+item+'" class="prompt-'+Math.floor(Date.now() / 1000)+'"> '+item+'</label></td></tr>';
                          });
                        if(req.params.promptType == 3){
         outline += '<tr><td width="130px"><input type="button" class="btn btn-primary btn-flat" onclick=selectRegionPrompt("prompt-'+Math.floor(Date.now() / 1000)+'") value="Next" id="period-prompt"></td></tr>';
                        }
        else if(req.params.promptType == 2){
         outline += '<tr><td width="130px"><input type="button" class="btn btn-primary btn-flat" onclick=selectBusinessPrompt("prompt-'+Math.floor(Date.now() / 1000)+'") value="Next" id="region-prompt"></td></tr>';
                        }
        else if(req.params.promptType == 1){
         outline += '<tr><td width="130px"><input type="button" class="btn btn-primary btn-flat" onclick=generateAnalysis("prompt-'+Math.floor(Date.now() / 1000)+'") value="Generate Analysis" id="business-prompt"></td></tr>';
                        }
         
         outline += '</tbody> </table>';
                             res.json({
                            data:outline
                            });   
                        });
}
    function getFromattedParam(param) {
        if(param.indexOf(',') > -1){
           return param.replace(/,/g,', ').split(',');
            // param = '\''+param;
            // //param = param.replace(',', '","');
            // param = param.split(',').join('\',\'');
            // param = param +'\'';
        }
        else if(param){
             var array = [];
                    while(array.length > 0) {
            array.pop();
            }
            array.push(param);
            return array;
        }
        else{
            var array = [];
                    while(array.length > 0) {
            array.pop();
            }
            array.push('All');
            return array;
        }
        //return param;
    }
var generateAnalysis = function(req, res, next) {
    Store.FinanceResponseWithMultiplePrompts(getFromattedParam(req.params.region.toString()),getFromattedParam(req.params.business.toString()),getFromattedParam(req.params.period.toString()),'AR_Outstanding')
                                      .then(function (financeData) {
                                                       // var outline ='This analysis measures <bld>AR By Region/Business of the Relationship Manager | As of </bld>. The <bld></bld> values will be on currency USD at 2017 MMC Budget Rate (000\'s). Value of <bld>'+metricsEntity.entity+'</bld> for Business - <bld>'+busniessEntity.resolution.values[0]+'</bld> and Region - <bld>'+regionsEntity.resolution.values[0]+'</bld> is ';
                                                       var outline ='For selected prompt answers<br>';
                                                       outline += '<span class="badge bg-orange">Period:</span> '+getFromattedParam(req.params.period.toString())+'<br>';
                                                       outline += '<span class="badge bg-purple">Region:</span> '+getFromattedParam(req.params.region.toString())+'<br>';
                                                       outline += '<span class="badge bg-blue">Business:</span> '+getFromattedParam(req.params.business.toString())+'<br>';
                                                    outline += 'Total <bld>Accounts Receivable</bld> value is: ';
                                                       var totalAmount = 0;
                                                        financeData.forEach(function(item){
                                                            totalAmount =parseInt(totalAmount) + parseInt((item.AR/1000).toFixed(0));
                                                            
                                                        });
                                                        outline +=getColorCode(totalAmount);
                                                        res.json({
                                                                data:outline
                                                                });   
                                                            });

}               
var permiumAnalysis = function(req, res, next) {
       Store.PremiumResponse(req.params.premiumType)
                       .then(function (premiums) {
                        var aray = [];
                        premiums.forEach(function(item){
                            aray.push(item.Value);
                        });
                        var output = maxMinAvg(aray);
                                    var maxIndex = premiums.findIndex(function(val) {
                                      return val.Value == output[0]
                                    });
                                    var minIndex = premiums.findIndex(function(val) {
                                      return val.Value == output[1]
                                    });
                        var outline ='This analysis measures Premium Amount by '+req.params.premiumType+'.<br/><ul type="disc"><li>Total Aggregated Premium across <bld>'+premiums.length+'</bld> entites is <bld>$'+output[1]+'</bld> which averages to <bld>$'+Math.round(output[3],0)+'</bld>.</li><li> The distribution ranges from <bld>$'+premiums[minIndex].Value+'</bld> ('+premiums[minIndex].Header+') to  <bld>$'+premiums[maxIndex].Value+'</bld> ('+premiums[maxIndex].Header+'), a difference of <bld>$'+(premiums[maxIndex].Value-premiums[minIndex].Value+'</bld>.</li></ul>');
                             res.json({
                            data:outline
                            });   
                        });
}
var claimAnalysis =function(req, res, next) {
       Store.ClaimsResponse(req.params.claimType)
                        .then(function (claims) {
                        var aray = [];
                        claims.forEach(function(item){
                            aray.push(item.Value);
                        });
                        var output = maxMinAvg(aray);
                                    var maxIndex = claims.findIndex(function(val) {
                                      return val.Value == output[0]
                                    });
                                    var minIndex = claims.findIndex(function(val) {
                                      return val.Value == output[1]
                                    });
                    
                        var outline ='This analysis measures Claims Amount by '+req.params.claimType+'. <br/><ul type="disc"><li>Total Aggregated Claims across <bld>'+claims.length+'</bld> entites is <bld>$'+output[2]+'</bld> which averages to <bld>$'+(Math.round(output[2]/aray.length,0))+'</bld>.</li><li> The distribution ranges from <bld>$'+claims[minIndex].Value+'</bld> ('+claims[minIndex].Header+') to  <bld>$'+claims[maxIndex].Value+'</bld> ('+claims[maxIndex].Header+'), a difference of <bld>$'+(claims[maxIndex].Value-claims[minIndex].Value+'</bld>.</li></ul>');
                         res.json({
                            data:outline
                            });   
                        });
}
         
server.post('/api/chat', webChat);
server.post('/api/ReportList', reportList);
server.post('/api/ClaimAnalysis', claimAnalysis);
server.post('/api/PromptAnalysis', promptAnalysis);
server.post('/api/PermiumAnalysis', permiumAnalysis);
server.post('/api/GenerateAnalysis', generateAnalysis);
server.post('/api/ReportsByMetric', ReportsByMetric);
server.post('/api/TalentReports', TalentReports);
server.post('/api/ExecuteReport', ExecuteReport);
server.post('/api/CubeInformation', CubeInformation);


function maxMinAvg(arr) {
    var max = arr[0];
    var min = arr[0];
    var sum = arr[0];
    for (var i = 1; i < arr.length; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
        if (arr[i] < min) {
            min = arr[i];
        }
        sum = sum + arr[i];
    }
    return [max, min, sum, sum/arr.length]; 
} 

function getColorCode(val){
    if(val>100){
        return '<span class="badge bg-green">$ '+val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")+'</span>';
    }
    else if(val>80){
        return '<span class="badge bg-orange">$ '+val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")+'</span>';
    }
    else{
        return '<span class="badge bg-red">$ '+val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")+'</span>';
    }
}
function getFormattedCurrency(val){
        return '$ '+val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function toTitleCase(str)
{
    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}


function getSqlCondition(metricName,filter,value){
var columnName = metricName == 'CYR'?'Current_Year_Revenue':'Total_Opp_revenue';
    switch(filter){
        case 'less than':
        return columnName +'<'+ (value/100)
        break;
        case 'less than equals to':
        return columnName +'<='+ (value/100)
        break;
        case 'less than equal to':
        return columnName +'<='+ (value/100)
        break;
        case 'greater than':
        return columnName +'>'+ (value/100)
        break;
        case 'greater than equals to':
        return columnName +'>='+ (value/100)
        break;
        case 'greater than equal to':
        return columnName +'>='+ (value/100)
        break;
        default:
        return ''
        break;
    }
}