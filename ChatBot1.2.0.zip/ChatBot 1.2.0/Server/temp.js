var demo = function () {
};

demo.prototype = function () {


    // ******** Configuration

    //REST Server
    var RESTServerIP = "10.52.12.11";                 // Logical name of the REST Server
    var RESTServerPort = "10086";                 // Port of the REST Server
    var ContentType = "application/vnd.mstr.dataapi.v0+json"; // To be added in each request as a request header

    //MicroStrategy Intelligence Server
    var IServer = "10.52.12.11";                  // Logical name of the MicroStrategy IServer
    var IServerPort = 34952;                      // Port of the MicroStrategy IServer
    var projectName = "APAC_CAD_Analytics(China)";   // Name of the MicroStrategy Project
    var username = "administrator";               // Credentials to connect to the MicroStrategy Project
    var password = "madmin";

    //MicroStrategy Object
    var isCube = true;                            // True if running a cube, false if running a report
    var id = "1033A63E4654EEAD713598A78D347514";  // Id of the cube or report used
    var itemPerPage = 200;                         // Number of items the table will display per page


    // ******** Constants

    var BASE_URL = "http://" + RESTServerIP + ":" + RESTServerPort + "/json-data-api/";
    var TARGET = isCube ? "cubes/" : "reports/";
    var CURRENT_URL = BASE_URL + TARGET;
    var UPDATE_PAGINATION_MODE = {
        INIT: 0,
        NEXT: 1,
        PREV: 2
    };
    var LIST_VIEW = {
        attribute: 0,
        metric: 1
    };

    // ******** Global variables

    var json;                                      // Contains the retrieved json output
    var authToken;                                 // Contains the session id which will be used in every api call
    var instanceId;                                // Contains the instance id which is a reference to a report created in memory.
    var paging = {                                 // Used to handle pagination
        offset: 0,
        limit: itemPerPage
    };
    var autoload = true;                           // Determine if the api call should be made as soon as we select at least one attribute and one metric or using a apply button
    var attributeList = null;                      // Contains the attribute list of the json output
    var metricList = null;                         // Contains the metric list of the json output
    var attributeListView, metricListView;         // Declare list views
    var postBody;                                  // Contains the input body of the api call


    // ******** Public Functions

    var  start = function start() {
            /*  Instructions to be done when loading the js*/

            createSession(); //Create session

            //Create attribute list view
            attributeListView = createListView(LIST_VIEW.attribute);
            attributeListView.items = [{
                name: "Loading attributes..."
            }];
            attributeListView.attach();
            attributeListView.refresh();

            //Create metric list view
            metricListView = createListView(LIST_VIEW.metric);
            metricListView.items = [{
                name: "Loading metrics..."
            }];
            metricListView.attach();
            metricListView.refresh();

            //Load the Google Table Chart
            google.charts.load('current', {
                'packages': ['table']
            });
        },

        createReport = function createReport() {
            /*  Trigger when clicking on the "apply" button, run a report with the selected attributes and metrics  */

            if (noneOrBothAreEmpty()) {
                if (bothAreEmpty()) { // If both are empty get a report with all data of the cube
                    postBody = JSON.stringify({});
                }
                else {
                    postBody = JSON.stringify({
                        requestedObjects: {
                            attributes: attributeListView.items.filter(function (item, i) {
                                return attributeListView.selectedIndices[i]
                            }),
                            metrics: metricListView.items.filter(function (item, i) {
                                return metricListView.selectedIndices[i]
                            })
                        }
                    })
                }
                getData();
            }
        },

        getMoreData = function getMoreData() {
            /*  After we run a report, we can reuse it (for performance purpose) using the instanceId reference we got from the first time we run it (using a POST method)  */

            $.ajax({
                type: "GET",
                url: CURRENT_URL + id + "/instances/" + instanceId + "?offset=" + paging.offset + "&limit=" + paging.limit,
                beforeSend: function (xhr2) {
                    xhr2.setRequestHeader("X-MSTR-AuthToken", authToken);
                    xhr2.setRequestHeader("Accept", ContentType);
                },
                success: function (data) {
                    json = data;
                    plotTable();
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    if (errorThrown === "Unauthorized") { // if the session expired, recreate a new one.
                        createSession();
                    }
                }
            });
        },

        plotTable = function plotTable() {
            /*  Plot the Google Chart table using the json output of the last api call  */

            var attributes = [];
            var metrics = [];
            var root = json.result.data.root;
            var data = [];
            var row = [];

            google.charts.setOnLoadCallback(drawTable);

            // ******** Functions used to plot table

            function drawTable() {
                /*  Draw the Google Table chart  */
                var dataTable = new google.visualization.DataTable();

                var definition = json.result.definition;

                //Add attributes in the columns of the table
                definition.attributes.forEach(function (attribute) {
                    dataTable.addColumn('string', attribute.name);
                    attributes.push(attribute.name);
                });

                //Add metrics in the columns of the table
                definition.metrics.forEach(function (metric) {
                    dataTable.addColumn('number', metric.name);
                    metrics.push(metric.name);
                });

                search(root); // Flatten the tree structure data into rows (will be added to data)

                dataTable.addRows(data);

                var table = new google.visualization.Table(document.getElementById('table_div'));

                var optionsTable = {
                    showRowNumber: false,
                    width: '100%',
                    height: '100%',
                };
                table.draw(dataTable, optionsTable);

                google.visualization.events.addListener(table, 'page');

            }

            // **** Functions to flatten the tree data (using a depth first recursive algorithm)

            function visit(node) {
                /*  Apply what needs to be done when visiting a node
                 *  @param {Object} node visited */

                if (node.element)
                    row[node.depth] = utils.decodeHtml(node.element.name);
                if (node.metrics) {
                    metrics.forEach(function (metric, i) {
                        row[node.depth + 1 + i] = {
                            v: (node.metrics[metric].rv),
                            f: (node.metrics[metric].fv)
                        };
                    });
                    data.push(row);
                    row = row.slice();
                }
            }

            function search(root) {
                /*  Goes recursively though the input root tree
                 *  @param {Object} root node of the tree to be searched */

                if (root) {
                    visit(root);
                    root.visited = true;
                    if (!root.metrics) {
                        root.children.forEach(function (node) {
                            if (!node.visited) {
                                search(node);
                            }
                        });
                    }
                }
            }
        },

        navNext = function navNext() {
            /*  Triggered when clicking on the next button (right arrow), fetch the next {limit} number of row  */

            updatePagination(json, UPDATE_PAGINATION_MODE.NEXT);
            getMoreData();
        },

        navPrevious = function navPrevious() {
            /*  Triggered when clicking on the previous button (left arrow), fetch the previous {limit} number of row  */

            updatePagination(json, UPDATE_PAGINATION_MODE.PREV);
            getMoreData();
        },

        switchAutoloadMode = function changeAutoloadmode(element) {
            /*  Triggered when checking/unchecking the auto-load checkbox, it switches the auto-load mode
             @param {Object} input checkbox object*/
            autoload = element.checked;
            $('button').prop('disabled', autoload);
            if (autoload) {
                createReport();
            }
        };

    // ******** Internal Functions

    function createSession() {
        /*  Create Session  */
        $.ajax({
            type: 'POST',
            url: BASE_URL + "sessions",
            beforeSend: function (xhr) {
                xhr.setRequestHeader("X-IServerName", IServer);
                xhr.setRequestHeader("X-Port", IServerPort);
                xhr.setRequestHeader("X-ProjectName", projectName);
                xhr.setRequestHeader("X-Username", username);
                xhr.setRequestHeader("Accept", ContentType);
                xhr.setRequestHeader("X-Password", password);
            },
            success: function (response) {
                authToken = response.authToken;
                getData();
            },
            error: function (e) {
                console.log(e);
            }
        });
    }

    function getData() {
        /*  Create report from the Cube using ad hoc metrics and attributes selected from the listviews  */

        var params = {
            type: "POST",
            url: CURRENT_URL + id + "/instances?offset=" + 0 + "&limit=" + paging.limit,
            beforeSend: function (xhr2) {
                xhr2.setRequestHeader("X-MSTR-AuthToken", authToken);
                xhr2.setRequestHeader("Accept", ContentType);
            },
            success: function (data) {
                instanceId = data.instanceId;
                json = data;
                paging = json.result.data.paging;
                loadDefinitions(); // get the list of attributes and metrics
                updatePagination(json, UPDATE_PAGINATION_MODE.INIT);
                plotTable();
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (errorThrown === "Unauthorized") { // if the session expired, recreate a new one.
                    createSession();
                }
            }
        };
        if (postBody) {
            $.extend(params, {
                data: postBody,
                contentType: ContentType
            })
        }
        $.ajax(params);
    }


    function loadDefinitions() {
        /*  Load the attributes and the metrics list from the json.definitions output  */

        if (attributeList) { // The attribute list already exists
            return;
        }
        attributeList = json.result.definition.attributes;
        metricList = json.result.definition.metrics;
        attributeListView.items = attributeList;
        metricListView.items = metricList;
        attributeListView.refresh();
        metricListView.refresh();

    }

    function noneAreEmpty() {
        /*  Return true if none of list view selections are empty  */
        var isAttributeListEmpty = jQuery.isEmptyObject(attributeListView.selectedIndices),
            isMetricListEmpty = jQuery.isEmptyObject(metricListView.selectedIndices);
        return !isAttributeListEmpty && !isMetricListEmpty;
    }

    function bothAreEmpty() {
        /*  Return true if both list view selections are empty  */
        var isAttributeListEmpty = jQuery.isEmptyObject(attributeListView.selectedIndices),
            isMetricListEmpty = jQuery.isEmptyObject(metricListView.selectedIndices);
        return isAttributeListEmpty && isMetricListEmpty;
    }

    function noneOrBothAreEmpty() {
        /*  Return if we should make a run report call  */
        return noneAreEmpty() || bothAreEmpty();
    }

    function updatePagination(json, mode) {
        /*  Update pagination offset and enable/disable pagination button
         @param {Object} json output from the last getData or getMoreData API call
         @param {Object} json.result.data.paging object containing pagination information
         @param {int} indicate the source of the update pagination*/

        paging = json.result.data.paging;

        paging.offset += paging.limit * (mode === UPDATE_PAGINATION_MODE.NEXT ? 1 : -1);// update the offset for the next call

        paging.offset = Math.max(0, paging.offset);  // the offset can't be negative

        paging.offset = Math.min(paging.offset, paging.total); // the offset can't be negative

        //no more next data to fetch
        $('#nextB').toggleClass('disabled', paging.offset + paging.limit >= paging.total);


        //no more previous data to fetch
        $('#previousB').toggleClass('disabled', paging.offset <= 0);

    }

    function createListView(listViewNumber) {
        /*  Create a list view object ( for either attributes or metrics )
         @param {int} # of the list view */
        return utils.createListView({
            domNode: $('.object-list')[listViewNumber],
            handleItemClick: function (params) {
                if (autoload) {
                    createReport();
                }
            }
        });
    }

    return {
        start: start,
        createReport: createReport,
        switchAutoloadMode: switchAutoloadMode,
        navNext: navNext,
        navPrevious: navPrevious
    };
}();