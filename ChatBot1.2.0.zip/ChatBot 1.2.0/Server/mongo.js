var mongoose = require("mongoose");
mongoose.Promise = global.Promise;

var option = {
    server: {
        socketOptions: {
            keepAlive: 300000,
            connectTimeoutMS: 30000
        }
    },
    replset: {
        socketOptions: {
            keepAlive: 300000,
            connectTimeoutMS: 30000
        }
    }
};

mongoose.connect("mongodb://localhost:27017/luis", { useMongoClient: true });

// // var db = mongoose.connection;
// // var Schema = mongoose.Schema;
// //  //"Business": "Health", "Country": "Argentina",
// //  // "Period": "13-Jan", "Region": "Growth Markets",
// //  // "Zone": "Latin America", "AR_Outstanding": 1489.9006, "Row_Count": 1, "Unbilled_Wip": 0
// //  var arapSchema = new Schema({
// //     Business:String,
// //     Country:String,
// //     Period:String,
// //     Region:String,
// //     Zone:String,
// //     AR_Outstanding:Number,
// //     Row_Count:Number,
// //     Unbilled_Wip:Number
// //    });
// // var arapData = mongoose.model('arap', arapSchema);
// // // arap.find({}, function(err, data){
// // //     });
// // //     arap.find(function (err, data) {
// // //   if (err) return console.error(err);
// // //     });
// // arapData.find({Business:'Career'}).toArray(function(err, result) {
// //   if (err) return handleError(err);
// //   // 'athletes' contains the list of athletes that match the criteria.
// // })
// // //  var mongo = mongoose.model("luis", luisSchema, 'utterance');
// // // arapData.find().where('Business').equals('Career').where('Period').equals('17-Mar').limit(1).exec(function(err,data){
// // // });
// // // Athlete.
// // //   find().
// // //   where('sport').equals('Tennis').
// // //   where('age').gt(17).lt(50).  //Additional where query
// // //   limit(5).
// // //   sort({ age: -1 }).
// // //   select('name age').
// // //   exec(callback); 
// //  module.exports =arapData;


// //  var MongoClient = require('mongodb').MongoClient;
// // var url = "mongodb://localhost:27017/";

// // MongoClient.connect(url, function(err, db) {
// //   if (err) throw err;
// //   var dbo = db.db("apac");
// //   dbo.collection("arap").findOne({}, function(err, result) {
// //     if (err) throw err;
// //     db.close();
// //   });
// // }); 



// //  var data = new Promise(function(resolve, reject) {
// //         var MongoClient = require('mongodb').MongoClient;
// // var url = "mongodb://localhost:27017/";

// // MongoClient.connect(url, function(err, db) {
// //   if (err) throw err;
// //   var dbo = db.db("apac");
// //    dbo.collection("arap").find({Business:'Career'}).toArray(function(err, result) {
// //     if (err) throw err;
// //         resolve(result);
// //     db.close();
// //   });
// // }); 
// //   });


// //module.exports = collection;


// var MongoClient = require('mongodb').MongoClient;
// var dbPath = 'mongodb://localhost:27017/apac';
// //var Promise = require('rsvp').Promise;

// module.exports = {
//   arapCollection: function() {
//     return new Promise(function(resolve, reject) {
//       MongoClient.connect(, function(err, db) {
//         if (err) {
//           reject(err);  
//         } else {
//           resolve(db);
//         }        
//       })
//     }).then(function(db) {
//       return new Promise(function(resolve, reject) {
//         var collection = db.collection('arap');
        
//         collection.find().toArray(function(err, items) {
//           if (err) {
//             reject(err);
//           } else {
//             resolve(items);
//           }          
//         });
//       });
//     });
//   }
// };