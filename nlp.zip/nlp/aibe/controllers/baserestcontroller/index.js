const BaseRestController = require('./baserest.controller');

module.exports = {
  BaseRestController,
};
