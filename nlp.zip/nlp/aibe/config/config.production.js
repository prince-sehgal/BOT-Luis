var config = require('./config.global');

config.logger.level = config.logger.levels.all;
// config.modules.enterpriseconnector.baseurl = 'http://localhost:83/econnector';

module.exports = config;