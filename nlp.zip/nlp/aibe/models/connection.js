var mongoose = require('mongoose');
var config = require('../config');
var db = mongoose.connect(config.mongo.uri, { useNewUrlParser: true });
mongoose.set('useCreateIndex', true);
// var db = mongoose.connect(config.mongo.uri, { useMongoClient: true });
//module.exports = db;
// console.log(config.mongo.uri);