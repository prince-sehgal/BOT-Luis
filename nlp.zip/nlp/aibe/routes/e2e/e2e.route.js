const express = require('express');
const router = express.Router();
var dataCtrl = require('../../controllers/e2e/e2e.controller.js');

router.post('/', function (req, res) {
    dataCtrl.processUserQuery(req, res)
    /*.subscribe((result)=>{
        res.status(200).send(result);
    },
    (error)=>{
        res.status(500).send(error.message)
    })*/
});

module.exports = router;