<a name="0.7.27"></a>
## [0.7.27](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.26...v0.7.27) (2018-04-18)



<a name="0.7.26"></a>
## [0.7.26](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.25...v0.7.26) (2018-04-17)



<a name="0.7.25"></a>
## [0.7.25](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.24...v0.7.25) (2018-04-16)



<a name="0.7.24"></a>
## [0.7.24](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.23...v0.7.24) (2018-04-12)



<a name="0.7.23"></a>
## [0.7.23](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.22...v0.7.23) (2018-04-11)



<a name="0.7.22"></a>
## [0.7.22](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.21...v0.7.22) (2018-04-09)



<a name="0.7.21"></a>
## [0.7.21](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.20...v0.7.21) (2018-04-05)



<a name="0.7.20"></a>
## [0.7.20](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.19...v0.7.20) (2018-04-04)



<a name="0.7.19"></a>
## [0.7.19](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.18...v0.7.19) (2018-04-02)



<a name="0.7.18"></a>
## [0.7.18](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.17...v0.7.18) (2018-03-29)



<a name="0.7.17"></a>
## [0.7.17](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.16...v0.7.17) (2018-03-27)


### Bug Fixes

* **router:** [MOSUI-239] use custom router serializer with ngrx ([856cc19](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/856cc19)), closes [#264](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/264)



<a name="0.7.16"></a>
## [0.7.16](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.15...v0.7.16) (2018-03-27)



<a name="0.7.15"></a>
## [0.7.15](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.14...v0.7.15) (2018-03-26)



<a name="0.7.14"></a>
## [0.7.14](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.13...v0.7.14) (2018-03-26)



<a name="0.7.13"></a>
## [0.7.13](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.12...v0.7.13) (2018-03-26)



<a name="0.7.12"></a>
## [0.7.12](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.11...v0.7.12) (2018-03-19)



<a name="0.7.11"></a>
## [0.7.11](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.10...v0.7.11) (2018-03-12)



<a name="0.7.10"></a>
## [0.7.10](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.9...v0.7.10) (2018-03-12)



<a name="0.7.9"></a>
## [0.7.9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.8...v0.7.9) (2018-03-12)



<a name="0.7.8"></a>
## [0.7.8](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.7...v0.7.8) (2018-03-09)



<a name="0.7.7"></a>
## [0.7.7](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.6...v0.7.7) (2018-03-09)



<a name="0.7.6"></a>
## [0.7.6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.5...v0.7.6) (2018-03-09)



<a name="0.7.5"></a>
## [0.7.5](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.4...v0.7.5) (2018-03-08)



<a name="0.7.4"></a>
## [0.7.4](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.3...v0.7.4) (2018-03-05)



<a name="0.7.3"></a>
## [0.7.3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.2...v0.7.3) (2018-03-02)



<a name="0.7.2"></a>
## [0.7.2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.1...v0.7.2) (2018-03-02)



<a name="0.7.1"></a>
## [0.7.1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.7.0...v0.7.1) (2018-02-27)



<a name="0.7.0"></a>
# [0.7.0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.94...v0.7.0) (2018-02-22)


### Bug Fixes

* **package:** changelog command ([1026b02](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1026b02))


### Features

* angular cli replatform with ngrx 5 setup ([fd023cc](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/fd023cc)), closes [#256](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/256)



<a name="0.6.94"></a>
## [0.6.94](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.93...v0.6.94) (2018-02-22)



<a name="0.6.93"></a>
## [0.6.93](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.92...v0.6.93) (2018-02-19)



<a name="0.6.92"></a>
## [0.6.92](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.91...v0.6.92) (2018-02-16)



<a name="0.6.91"></a>
## [0.6.91](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.90...v0.6.91) (2018-02-14)



<a name="0.6.90"></a>
## [0.6.90](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.89...v0.6.90) (2018-02-13)



<a name="0.6.89"></a>
## [0.6.89](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.88...v0.6.89) (2018-02-12)



<a name="0.6.88"></a>
## [0.6.88](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.87...v0.6.88) (2018-02-12)



<a name="0.6.87"></a>
## [0.6.87](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.86...v0.6.87) (2018-02-08)



<a name="0.6.86"></a>
## [0.6.86](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.85...v0.6.86) (2018-02-06)



<a name="0.6.85"></a>
## [0.6.85](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.84...v0.6.85) (2018-02-02)



<a name="0.6.84"></a>
## [0.6.84](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.83...v0.6.84) (2018-02-02)



<a name="0.6.83"></a>
## [0.6.83](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.82...v0.6.83) (2018-02-02)



<a name="0.6.82"></a>
## [0.6.82](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.81...v0.6.82) (2018-02-02)



<a name="0.6.81"></a>
## [0.6.81](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.80...v0.6.81) (2018-02-02)



<a name="0.6.80"></a>
## [0.6.80](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.79...v0.6.80) (2018-02-01)



<a name="0.6.79"></a>
## [0.6.79](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.78...v0.6.79) (2018-01-31)



<a name="0.6.78"></a>
## [0.6.78](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.77...v0.6.78) (2018-01-31)



<a name="0.6.77"></a>
## [0.6.77](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.76...v0.6.77) (2018-01-31)



<a name="0.6.76"></a>
## [0.6.76](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.75...v0.6.76) (2018-01-31)



<a name="0.6.75"></a>
## [0.6.75](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.74...v0.6.75) (2018-01-30)


### Features

* angular-cli migration tool ([6f0abac](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6f0abac))



<a name="0.6.74"></a>
## [0.6.74](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.73...v0.6.74) (2018-01-26)



<a name="0.6.73"></a>
## [0.6.73](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.72...v0.6.73) (2018-01-25)



<a name="0.6.72"></a>
## [0.6.72](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.71...v0.6.72) (2018-01-23)



<a name="0.6.71"></a>
## [0.6.71](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.70...v0.6.71) (2018-01-22)



<a name="0.6.70"></a>
## [0.6.70](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.69...v0.6.70) (2018-01-19)



<a name="0.6.69"></a>
## [0.6.69](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.68...v0.6.69) (2018-01-19)



<a name="0.6.68"></a>
## [0.6.68](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.67...v0.6.68) (2018-01-17)



<a name="0.6.67"></a>
## [0.6.67](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.66...v0.6.67) (2018-01-11)



<a name="0.6.66"></a>
## [0.6.66](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.65...v0.6.66) (2018-01-08)



<a name="0.6.65"></a>
## [0.6.65](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.64...v0.6.65) (2018-01-02)



<a name="0.6.64"></a>
## [0.6.64](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.63...v0.6.64) (2017-12-26)



<a name="0.6.63"></a>
## [0.6.63](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.62...v0.6.63) (2017-12-21)



<a name="0.6.62"></a>
## [0.6.62](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.61...v0.6.62) (2017-12-19)



<a name="0.6.61"></a>
## [0.6.61](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.60...v0.6.61) (2017-12-12)



<a name="0.6.60"></a>
## [0.6.60](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.59...v0.6.60) (2017-12-12)



<a name="0.6.59"></a>
## [0.6.59](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.58...v0.6.59) (2017-12-07)


### Features

* **package:** match [@angular](https://github.com/angular)/cli defaults ([f259eb9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f259eb9))



<a name="0.6.58"></a>
## [0.6.58](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.57...v0.6.58) (2017-11-29)



<a name="0.6.57"></a>
## [0.6.57](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.56...v0.6.57) (2017-11-29)



<a name="0.6.56"></a>
## [0.6.56](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.55...v0.6.56) (2017-11-21)



<a name="0.6.55"></a>
## [0.6.55](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.54...v0.6.55) (2017-11-20)



<a name="0.6.54"></a>
## [0.6.54](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.53...v0.6.54) (2017-11-17)



<a name="0.6.53"></a>
## [0.6.53](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.52...v0.6.53) (2017-11-16)



<a name="0.6.52"></a>
## [0.6.52](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.51...v0.6.52) (2017-11-16)



<a name="0.6.51"></a>
## [0.6.51](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.50...v0.6.51) (2017-11-14)



<a name="0.6.50"></a>
## [0.6.50](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.49...v0.6.50) (2017-11-10)



<a name="0.6.49"></a>
## [0.6.49](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.48...v0.6.49) (2017-11-08)



<a name="0.6.48"></a>
## [0.6.48](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.47...v0.6.48) (2017-11-07)



<a name="0.6.47"></a>
## [0.6.47](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.46...v0.6.47) (2017-11-06)



<a name="0.6.46"></a>
## [0.6.46](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.45...v0.6.46) (2017-11-03)



<a name="0.6.45"></a>
## [0.6.45](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.44...v0.6.45) (2017-11-01)



<a name="0.6.44"></a>
## [0.6.44](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.43...v0.6.44) (2017-10-30)



<a name="0.6.43"></a>
## [0.6.43](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.42...v0.6.43) (2017-10-27)



<a name="0.6.42"></a>
## [0.6.42](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.41...v0.6.42) (2017-10-27)



<a name="0.6.41"></a>
## [0.6.41](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.40...v0.6.41) (2017-10-23)


### Bug Fixes

* AOT message copy ([1a7d74f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1a7d74f))



<a name="0.6.40"></a>
## [0.6.40](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.39...v0.6.40) (2017-10-20)


### Bug Fixes

* **ngrx-devtools:** include ngrx devtools in the correct position ([04dad6d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/04dad6d))



<a name="0.6.39"></a>
## [0.6.39](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.38...v0.6.39) (2017-10-19)



<a name="0.6.38"></a>
## [0.6.38](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.37...v0.6.38) (2017-10-19)



<a name="0.6.37"></a>
## [0.6.37](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.36...v0.6.37) (2017-10-18)



<a name="0.6.36"></a>
## [0.6.36](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.35...v0.6.36) (2017-10-17)



<a name="0.6.35"></a>
## [0.6.35](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.34...v0.6.35) (2017-10-16)



<a name="0.6.34"></a>
## [0.6.34](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.33...v0.6.34) (2017-10-15)



<a name="0.6.33"></a>
## [0.6.33](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.32...v0.6.33) (2017-10-15)



<a name="0.6.32"></a>
## [0.6.32](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.31...v0.6.32) (2017-10-15)



<a name="0.6.31"></a>
## [0.6.31](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.30...v0.6.31) (2017-10-15)



<a name="0.6.30"></a>
## [0.6.30](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.29...v0.6.30) (2017-10-15)



<a name="0.6.29"></a>
## [0.6.29](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.28...v0.6.29) (2017-10-15)



<a name="0.6.28"></a>
## [0.6.28](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.27...v0.6.28) (2017-10-12)



<a name="0.6.27"></a>
## [0.6.27](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.26...v0.6.27) (2017-10-12)



<a name="0.6.26"></a>
## [0.6.26](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.25...v0.6.26) (2017-10-10)



<a name="0.6.25"></a>
## [0.6.25](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.24...v0.6.25) (2017-10-06)



<a name="0.6.24"></a>
## [0.6.24](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.23...v0.6.24) (2017-10-04)



<a name="0.6.23"></a>
## [0.6.23](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.22...v0.6.23) (2017-10-02)



<a name="0.6.22"></a>
## [0.6.22](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.21...v0.6.22) (2017-09-28)



<a name="0.6.21"></a>
## [0.6.21](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.20...v0.6.21) (2017-09-28)



<a name="0.6.20"></a>
## [0.6.20](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.19...v0.6.20) (2017-09-26)



<a name="0.6.19"></a>
## [0.6.19](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.18...v0.6.19) (2017-09-19)



<a name="0.6.18"></a>
## [0.6.18](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.17...v0.6.18) (2017-09-15)



<a name="0.6.17"></a>
## [0.6.17](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.16...v0.6.17) (2017-09-13)


### Features

* **app:** add simple loader for main index file ([5d9e7a9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5d9e7a9))



<a name="0.6.16"></a>
## [0.6.16](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.15...v0.6.16) (2017-09-11)



<a name="0.6.15"></a>
## [0.6.15](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.14...v0.6.15) (2017-09-07)



<a name="0.6.14"></a>
## [0.6.14](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.13...v0.6.14) (2017-09-01)



<a name="0.6.13"></a>
## [0.6.13](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.12...v0.6.13) (2017-09-01)



<a name="0.6.12"></a>
## [0.6.12](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.11...v0.6.12) (2017-09-01)



<a name="0.6.11"></a>
## [0.6.11](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.10...v0.6.11) (2017-08-31)



<a name="0.6.10"></a>
## [0.6.10](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.9...v0.6.10) (2017-08-31)



<a name="0.6.9"></a>
## [0.6.9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.8...v0.6.9) (2017-08-31)



<a name="0.6.8"></a>
## [0.6.8](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.7...v0.6.8) (2017-08-29)



<a name="0.6.7"></a>
## [0.6.7](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.6...v0.6.7) (2017-08-25)


### Bug Fixes

* **hmr:** switch back to new release of angularclass/hmr ([34e8f0d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/34e8f0d))



<a name="0.6.6"></a>
## [0.6.6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.5...v0.6.6) (2017-08-24)



<a name="0.6.5"></a>
## [0.6.5](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.4...v0.6.5) (2017-08-23)



<a name="0.6.4"></a>
## [0.6.4](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.3...v0.6.4) (2017-08-23)



<a name="0.6.3"></a>
## [0.6.3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.2...v0.6.3) (2017-08-16)



<a name="0.6.2"></a>
## [0.6.2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.1...v0.6.2) (2017-08-15)



<a name="0.6.1"></a>
## [0.6.1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.6.0...v0.6.1) (2017-08-14)


### Features

* **console-pollyfill:** adds package for IE console log ([1da3d6e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1da3d6e))



<a name="0.6.0"></a>
# [0.6.0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.9...v0.6.0) (2017-08-11)



<a name="0.5.9"></a>
## [0.5.9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.8...v0.5.9) (2017-08-07)



<a name="0.5.8"></a>
## [0.5.8](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.7...v0.5.8) (2017-08-04)



<a name="0.5.7"></a>
## [0.5.7](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.6...v0.5.7) (2017-08-03)



<a name="0.5.6"></a>
## [0.5.6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.5...v0.5.6) (2017-08-02)



<a name="0.5.5"></a>
## [0.5.5](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.4...v0.5.5) (2017-08-02)



<a name="0.5.4"></a>
## [0.5.4](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.3...v0.5.4) (2017-07-28)



<a name="0.5.3"></a>
## [0.5.3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.0...v0.5.3) (2017-07-21)


### Bug Fixes

* **aot:** BUILD_AOT flag not being passed through ([afd3b30](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/afd3b30))
* **build:** lock zone version ([39783bc](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/39783bc))
* **build:** prevent double HMR and fix load order ([19213aa](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/19213aa))


### Features

* **angular:** angular upgrade to 4.2.x ([33c6ba4](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/33c6ba4))
* **lint:** create clickable links to code from CLI usage of linter ([f8782b3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f8782b3))
* **log:** print out if running with AOT build ([5edc127](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5edc127))
* **webpack:** webpack 3 and scope hoisting ([07339db](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/07339db))


### Performance Improvements

* **aot:** HTML minimize to prevent newlines from being compiled ([fb2f393](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/fb2f393))



<a name="0.5.2"></a>
## [0.5.2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.1...v0.5.2) (2017-07-14)


### Bug Fixes

* **build:** lock zone version ([39783bc](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/39783bc))


### Features

* **lint:** create clickable links to code from CLI usage of linter ([f8782b3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f8782b3))



<a name="0.5.1"></a>
## [0.5.1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.5.0...v0.5.1) (2017-06-28)


### Bug Fixes

* **aot:** BUILD_AOT flag not being passed through ([afd3b30](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/afd3b30))
* **build:** prevent double HMR and fix load order ([19213aa](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/19213aa))


### Features

* **angular:** angular upgrade to 4.2.x ([33c6ba4](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/33c6ba4))
* **log:** print out if running with AOT build ([5edc127](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5edc127))
* **webpack:** webpack 3 and scope hoisting ([07339db](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/07339db))


### Performance Improvements

* **aot:** HTML minimize to prevent newlines from being compiled ([fb2f393](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/fb2f393))



<a name="0.5.0"></a>
# [0.5.0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.4.3...v0.5.0) (2017-06-19)



<a name="0.4.3"></a>
## [0.4.3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.4.2...v0.4.3) (2017-06-13)



<a name="0.4.2"></a>
## [0.4.2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.4.1...v0.4.2) (2017-06-07)



<a name="0.4.1"></a>
## [0.4.1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.4.0...v0.4.1) (2017-06-02)



<a name="0.4.0"></a>
# [0.4.0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.3.1...v0.4.0) (2017-06-01)



<a name="0.3.1"></a>
## [0.3.1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.3.0...v0.3.1) (2017-05-26)



<a name="0.3.0"></a>
# [0.3.0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.2.3...v0.3.0) (2017-05-24)


### Performance Improvements

* **dev:** ignore node_modules in webpack watch ([72afb9e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/72afb9e))



<a name="0.2.3"></a>
## [0.2.3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.2.2...v0.2.3) (2017-05-18)


### Bug Fixes

* **build:** cache issue causing dev slow down ([937dc39](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/937dc39))
* **hmr:** fix missing flag to disable webpack-dev-server.js script (#1717) ([439e31a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/439e31a)), closes [#1717](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/1717)
* **local-dev:** move cache busting to prod and re-enable cache ([61b7ddf](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/61b7ddf))
* **polyfill:** web-animations-js polyfill for IE11 ([132898a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/132898a))
* **svg:** add polyfill for svg use on IE ([9355927](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/9355927))


### Features

*  ignoring mock-data dir if prod build (#1581) ([635669f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/635669f))
* Improve cache (busting) configuration (#1712) ([55433ce](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/55433ce))


### Performance Improvements

* **dev:** enable useCache and disable tslint-loader (#1718) ([f873d80](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f873d80))



<a name="0.2.2"></a>
## [0.2.2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.2.1...v0.2.2) (2017-05-10)



<a name="0.2.1"></a>
## [0.2.1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.2.0...v0.2.1) (2017-05-04)


### Bug Fixes

* **changelog:** changelog as part of release ([a6622e3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a6622e3))


### Performance Improvements

* **dev:** speed up local dev by 2x ([99acc5e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/99acc5e))



<a name="0.2.0"></a>
# [0.2.0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/v0.1.0...v0.2.0) (2017-05-04)


### Bug Fixes

* **continuous-integration:** disabled e2e tests ([69fe347](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/69fe347))
* **deployUrl:** correct bundle paths when deployUrl is set ([2606d50](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2606d50))
* **styles:** Added missing merceros styles import ([8bb5701](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/8bb5701))
* **zone.js:** updated zone.js to 0.8.5 to fix stacktrace error ([098b22a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/098b22a))


### Features

* **assets:** mercer branded assets package ([49f10b2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/49f10b2))
* **build:** enable html minification for index.html ([511ca09](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/511ca09))
* **deploy:** added configurable url for deploys ([4f4b0da](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/4f4b0da))
* **deploy:** modify head tags to point to the correct deployUrl in dev and prod ([657dd4a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/657dd4a))
* **deployUrl:** expose deployUrl as DEPLOY_URL to front end ([fdb7e58](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/fdb7e58))
* **favicon:** Mercer favicon ([2970420](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2970420))
* **linter:** added tslint auto fix task ([bd987fc](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/bd987fc)), closes [#108](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/108)
* **merceros:** deployUrl fix and MercerOS configured ([7157415](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/7157415))
* **meta:** meta data control for different environments ([bed6ac5](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/bed6ac5))
* **package:** added ngrx/effects ([054db23](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/054db23))
* **package:** package updates for angular, rxjs, zone.js, tslint, codelyzer, typescript ([c0f8c59](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c0f8c59))


### Performance Improvements

* **test:** prevent double running tslint and only run aot build during ci ([8120290](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/8120290))



<a name="0.1.0"></a>
# [0.1.0 - A New Hope](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/0.0.0...v0.1.0) (2017-03-28)

### Overview

* Features for supporting the MercerOS ecosystem
* Angular 4
* Environments setup
* Custom IE conditional include stylesheet and polyfills

### Bug Fixes

* aot build tslib target ([aa3ea87](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/aa3ea87))
* Index button is always 'active' (#1497) ([b28d52d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b28d52d))
* load gh-pages late (#1495) ([14d41ae](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/14d41ae)), closes [#1483](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/1483)
* make css chunks include via link ([8aedc17](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/8aedc17))
* removed bundled google analytics ([7280e21](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/7280e21))
* Rename export for detail module (#1300) ([f37fa22](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f37fa22))
* update to ngc-wrapped[@1](https://github.com/1).0.2 to handle node 5 error ([25782dd](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/25782dd))
* **config:** project config simplified with removal of variable overrides ([af63986](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/af63986))


### Features

* upgrade angular to angular 4 official ([5863e2a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5863e2a))
* **browser:** swap out base BrowserModule for BrowserAnimationsModule ([00eb3af](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/00eb3af))
* **build:** added postcss and autoprefixer to dev and prod ([47b0457](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/47b0457))
* **build:** added yarn.lock ([5598810](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5598810))
* **build:** copy mercer-os fonts to fonts directory ([5702af6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5702af6))
* **environment:** added environment config handling ([f20a045](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f20a045))
* **gh-pages:** support remotes with ssh protocol  (#1258) ([6f837da](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6f837da)), closes [#753](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/753)
* **icons-config:** webpack copy config for icon symbols svg definition file ([d3b7d33](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/d3b7d33))
* **merceros:** mercer os setup with sourcemaps ([b71369c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b71369c))
* **state:** initial ngrx integration ([b8474e7](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b8474e7))
* **test:** environment config for test environment ([8be48fc](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/8be48fc))
* ie conditional entrypoint for polyfills and styles ([1974480](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1974480))
* **versioning:** standard-changelog setup and 0.0.0 release ([a6b210d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a6b210d))
* added angular animations package for angular 4 ([b732725](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b732725))
* added commitizen support ([1010b7d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1010b7d))
* added components package ([9b06fed](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/9b06fed))
* make ci task headless for jenkins/docker environment ([1e9af80](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1e9af80))
* svgxuse polyfill for SVG support ([94cff54](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/94cff54))
* update style-loader to fix url imports ([23e5d47](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/23e5d47))
* upgrade angular to angular 4 rc3 ([e8c50f0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e8c50f0))
* use import() construct via ng-router-loader[@2](https://github.com/2).0.0 (#1387) ([35b48e5](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/35b48e5))



<a name="0.0.0"></a>
# [0.0.0 - Total Recall](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/compare/6b668bd...0.0.0) (2016-12-27)

### Overview

Initial release based on v5.2.0 of [angular2-webpack-starter](https://github.com/AngularClass/angular2-webpack-starter).

### Bug Fixes

* missing tslint ([ca9f401](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ca9f401))
* **01:** correct file requires ([9b2fbe4](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/9b2fbe4))
* **01:** remove redeclare array and include babel repl ([70afb1d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/70afb1d))
* **angular2.2:** wait for angular before disabling debug info (#1177) ([7481e09](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/7481e09))
* **app:** correct error message to install express ([2aa5803](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2aa5803))
* **app:** correct route of refresh ([e216318](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e216318))
* **app:** listen to input event ([3a8c246](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/3a8c246))
* **app:** typo ([eb60580](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/eb60580))
* **app-simple:** typo ([3933902](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/3933902))
* **app.spec:** provide state dependencies ([dab8328](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/dab8328))
* **AppState:** bool false value not returned ([0e74973](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0e74973)), closes [#673](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/673)
* **autosuggest/search:** use correct exports ([60c7f65](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/60c7f65))
* **bindings:** location bindings ([a1e1f53](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a1e1f53))
* **bootstrap:** syntax error ([061baa9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/061baa9))
* **build:** better windows support ([2ad011d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2ad011d))
* **CapitalizePipe:** update syntax to latest api ([f50c5f2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f50c5f2))
* **checkIfShadowDom:** update interface ([19d6cfc](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/19d6cfc))
* **draggable.ts:** Use toRx() of EventEmitter ([673471a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/673471a))
* **environment:** correct compiler config ([1617421](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1617421))
* **examples:** typo in the path of rxjs_examples ([0ebfcaa](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0ebfcaa))
* **helpers:** isWebpackDevServer() fix for windows, issue #757 (#966) ([c57de38](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c57de38)), closes [#757](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/757) [#966](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/966) [#757](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/757)
* **hmr:** tick on change ([f9f6557](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f9f6557))
* **home:** use correct exports ([94ec1c9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/94ec1c9))
* **home.spec:** provide state dependencies ([e538504](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e538504))
* **home.ts:** fix minor typo ([fae4c48](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/fae4c48))
* **karma.conf.js:** fix webpack config ([7f82d40](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/7f82d40))
* **ng2-patch:** template_compiler ([fa910ad](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/fa910ad))
* **package.json:** typo ([43d6649](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/43d6649))
* **pipes:** inject pipes in viewInjector ([925f8ee](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/925f8ee))
* **pipes:** PipeFactory as interface ([625ab07](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/625ab07))
* **polyfills:** provide workaround ([1661e4c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1661e4c))
* **protractor:** include protractor updates ([cee2d1d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/cee2d1d))
* **RouterActive:** truthy ([3318ff5](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/3318ff5))
* **rxjs_examples/timeflies:** use correct exports ([6482d8d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6482d8d))
* **rxjs-examples:** correct imports ([00d6c0f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/00d6c0f))
* **RxPipe:** correct imports ([51f47b8](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/51f47b8))
* **RxPipe:** correct typings ([b3c8a4f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b3c8a4f))
* **RxPipe:** update syntax to latest api ([864218c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/864218c))
* **Server:** fixed issue with running the sample backend api server alongside the webpack dev server. Also added a line on how to run the api server in the README ([ca83ec2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ca83ec2))
* **test:** closes #437 ([d80c76a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/d80c76a)), closes [#437](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/437)
* **todo:** correct imports ([2aed861](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2aed861))
* **TodoService:** include Injectable decorator ([821a65a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/821a65a))
* **tsconfig:** add typings/main.d.ts to filesGlob ([7f8c72e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/7f8c72e)), closes [#244](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/244)
* **tsconfig:** remove moduleResolution ([ba749a0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ba749a0))
* **typings:** missing semi-colons ([adca100](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/adca100))
* **typings:** rx ([629b0bf](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/629b0bf))
* **typings.json:** Wrong zone url ([74f96aa](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/74f96aa))
* **webpack:** check if default for es5 module ([4b5b94b](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/4b5b94b))
* **webpack:** correct import ([a24dd05](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a24dd05))
* **webpack.common:** correct package sort ([f26985d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f26985d))
* **webpack.conf:** err without output filename ([74c9830](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/74c9830)), closes [#360](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/360)
* **webpack.config:** correct config ([9736a48](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/9736a48))
* **webpack.config:** correct env default ([6db5e56](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6db5e56))
* **webpack.config:** correct sourcemap filename ([c2aa659](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c2aa659))
* **webpack.config:** remove a few excludes #84 ([79aef47](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/79aef47))
* missing typings and correct .gitignore ([5048268](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5048268))
* **webpack.config:** remove TRACEUR_RUNTIME ([6b668bd](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6b668bd))
* #901 (#905) ([3214cd2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/3214cd2))
* Angular2 dependency warning (#998) ([68e796f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/68e796f))
* angular2 perf problem ([74f99a3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/74f99a3)), closes [#979](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/979)
* async, hmr, remove platform ([c7cf01c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c7cf01c))
* bootstrap return componentRef ([555e47a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/555e47a))
* chunk order ([e4be77a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e4be77a))
* fakyAsync and sync test (#609) ([11f0713](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/11f0713))
* github-deploy fix using webpack 2 (#1089) ([93115ef](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/93115ef)), closes [#1089](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/1089) [#1078](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/1078)
* hmr ([1afe8da](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1afe8da))
* initial load of async child routes ([d4ecb3f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/d4ecb3f))
* **webpack.config:** typo ([ce2b303](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ce2b303))
* **webpack.config:** typo with common file ([a94e05f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a94e05f))
* **x-large:** use native element ([cd9d5de](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/cd9d5de))
* ng2lint ([6472c34](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6472c34))
* remove unnecessary whitespace ([6b13380](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6b13380))
* TestComponentBuilder  (#904) ([d59be2b](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/d59be2b))
* tests ([4277693](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/4277693))
* tslint issues (#870) ([dd9fa30](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/dd9fa30))
* Update webpack.prod.js (#920) ([e2552b8](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e2552b8))
* use core-js ([5bf36a6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5bf36a6))
* webpack-dev-server.js will 404 on build:dev (#643) ([c194d9c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c194d9c))
* zone.js bundling ([9f1256e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/9f1256e))


### Features

* [@angularclass](https://github.com/angularclass)/request-idle-callback ([01e4533](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/01e4533))
* ~ adding .nvmrc and respective docs ([e09ffb3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e09ffb3))
* Add missing type information to compile in case of `noImplicitAny` (#928) ([5324ba6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5324ba6))
* Added use of file-loader for jpg/png/gif files ([06ccce2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/06ccce2))
* angular2-hmr ([1d0d624](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1d0d624))
* AppState ([6a0c124](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6a0c124))
* async component ([ff76f25](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ff76f25))
* auto watch tests ([5f7438f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5f7438f))
* css example ([72aa0c0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/72aa0c0))
* dashboard component ([caefe17](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/caefe17))
* dynamic index.html ([360b57e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/360b57e))
* environment providers ([3d83193](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/3d83193))
* es6-promise-loader ([0f3edce](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0f3edce))
* example of resolved data route ([4234996](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/4234996))
* helpers ([6a2a1e9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6a2a1e9))
* include _fixed_cjs_http ([5f12d22](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5f12d22))
* include /home example ([4d14bfd](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/4d14bfd))
* include appPipesRegistry pipeline with rxAsync ([95f7ab0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/95f7ab0))
* include async loaded component ([86d1ada](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/86d1ada))
* include async route ([190b846](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/190b846))
* include custom_typings.d.ts ([2f253bf](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2f253bf))
* include default simple app component ([53ddfaa](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/53ddfaa))
* include github templates ([30a13ac](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/30a13ac))
* include img example ([d9ea3fb](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/d9ea3fb))
* **app:** include ngOnInit ([e9dd3f6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e9dd3f6))
* include karma ([5e5650b](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5e5650b))
* include long-stack-trace-zone for zone.js ([5c69325](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5c69325))
* include ngOnInit and constructor for +detail ([01ba738](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/01ba738))
* include routerInjectables ([e78a0c6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e78a0c6))
* include rxjs operators in dev ([19fefad](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/19fefad))
* ng2lint ([cf89721](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/cf89721))
* NoContent 404 ([0756298](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0756298))
* preload modules ([508b780](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/508b780))
* process true ([836734e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/836734e))
* protractor elementExplorer ([0446d23](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0446d23))
* remove.root src/ with mock-data ([7bcfbd9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/7bcfbd9))
* restoreInputValues for async routes ([23f7ce0](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/23f7ce0))
* save dom input values ([5502d33](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5502d33))
* show test coverage for original TS code (#1014) ([5cfdcd3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5cfdcd3))
* split polyfills from vendors ([b9737f6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b9737f6))
* switch to [@angularclass](https://github.com/angularclass)/conventions-loader ([948d19a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/948d19a))
* test tsconfig ([1dcd15d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/1dcd15d))
* todo component ([b37f9ab](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b37f9ab))
* tslint ([9e32111](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/9e32111))
* tslint-loader ([ca82b11](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ca82b11))
* update [@angular](https://github.com/angular)/router 3.0.0-beta.1 ([69fda99](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/69fda99))
* update routerActive ([727699d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/727699d))
* update typescript, remove typings ([2f441d9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2f441d9))
* Update webpack.dev.js to take respect optional HOST/PORT params (#827) ([b801b8c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b801b8c))
* update webpack2 ([817ea48](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/817ea48))
* use [@angularclass](https://github.com/angularclass)/conventions-loader ([dd10620](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/dd10620))
* use angular2-template-loader ([f8698cf](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f8698cf))
* use new [@angular](https://github.com/angular)/form api ([aecb5ad](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/aecb5ad))
* vendor file ([db619bd](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/db619bd))
* **01:** class declarations ([412afe1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/412afe1))
* **01:** Default Arguments ([ec6718e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ec6718e))
* **01:** destructuring ([c576c51](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c576c51))
* **01:** Enhanced Object Literals ([c6e7cb1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c6e7cb1))
* **01:** es6 modules ([99c1f4e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/99c1f4e))
* **01:** include arrow functions ([9755310](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/9755310))
* **01:** include rest/spread ([5e13ef6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5e13ef6))
* **01:** interpolation template feature ([d579398](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/d579398))
* **01:** split into files ([0a2aafd](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0a2aafd))
* **01:** template strings ([132f6ce](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/132f6ce))
* **01:** WIP es6 ([813f060](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/813f060))
* **02:** decorators ([f6f6aff](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f6f6aff))
* **02:** WIP typescript ([85dbdef](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/85dbdef))
* **03:** accessors, statics, modifiers ([ae770d3](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ae770d3))
* **03:** Member types and public modifiers ([a49253a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a49253a))
* **03:** WIP bootstrap ([e194831](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e194831))
* **04:** components ([867d8c1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/867d8c1))
* **05:** directives ([511347b](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/511347b))
* **07:** template syntax ([4a31f19](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/4a31f19))
* **13:** include pipes and capitalize ([6fa771d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/6fa771d))
* **14:** template forms ([5552b92](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5552b92))
* **about:** async mock-data with es6-promise ([2f24bcd](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2f24bcd))
* **Angular2:** Free Angular 2 Fundamentals Course ([89bef0d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/89bef0d))
* **Angular2:** Free Angular 2 Fundamentals Course (#818) ([4d7bbcd](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/4d7bbcd))
* **app:** include directive example ([647b5e4](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/647b5e4))
* **app:** include example Directive ([72ffd06](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/72ffd06))
* **app:** include ng-model ([f655dcf](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f655dcf))
* **app:** index.ts ([cdf2725](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/cdf2725))
* **app:** router active directive ([c2c59c5](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c2c59c5))
* **app-simple:** Http example ([5ba146b](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5ba146b))
* **app-simple:** import RouteConfig ([857da66](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/857da66))
* **app-simple:** log error to run the api ([f7cad59](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f7cad59))
* **app-simple:** update http example ([5ba5158](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5ba5158))
* **bootstrap:** correctly use env ([c9e5e01](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/c9e5e01))
* **bootstrap:** include http bindings ([cafe726](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/cafe726))
* **bootstrap:** include jsonp ([f4f6257](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f4f6257))
* **bootstrap:** include more injectables ([98de380](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/98de380))
* **bootstrap:** include ngProbe ([70f7958](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/70f7958))
* **bootstrap:** use shadow dom id chrome ([dbb76af](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/dbb76af))
* **browser-directives:** include reactive form directives ([5181d15](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5181d15))
* **changeDetectionInjectables:** include best check ([ef42b2e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ef42b2e))
* **common:** formInjectables ([10f0a0a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/10f0a0a))
* **common:** include formDirectives workaround ([fa59be1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/fa59be1))
* **common:** include location strategies ([805e51c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/805e51c))
* **common:** jitInjectables ([0d6f299](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0d6f299))
* **configurable-head-tags:** allow configuring head tags in a js module (#679) ([d529a74](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/d529a74))
* **custom-typings.d.ts:** comment about any def ([56a9bc7](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/56a9bc7))
* **directives:** Autofocus fix ([84db503](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/84db503))
* **directives:** list of directives file ([ec90d50](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ec90d50))
* **directives.ts:** angularDirectives with core/form/router ([48be9be](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/48be9be))
* **e2e:** use typescript ([06dbdfd](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/06dbdfd))
* **environment:** enableDebugTools ([da38850](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/da38850))
* **environment:** provide workaround prodmode ([a8c2c4e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a8c2c4e))
* **GameService:** bind to class ([98ff07c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/98ff07c))
* **github-deploy:** deploy to github pages (#645) ([4a07eef](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/4a07eef))
* **helpers:** packageSort, reverse ([294295e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/294295e))
* **hmr:** createInputTransfer ([94e95a2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/94e95a2))
* **home:** include directives ([46a3273](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/46a3273))
* **index.html:** base64 icon ([0ed34a8](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0ed34a8))
* **index.html:** material icons ([00419e1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/00419e1))
* **main:** hmr ([31e187e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/31e187e))
* **main:** use HashLocationStrategy ([ae30ee9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/ae30ee9))
* **package.json:** express-install with cors ([0b4e5c1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0b4e5c1))
* **pipes:** include simple capitalize  pipe example ([367cbae](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/367cbae))
* **platform:** directives ([962ea9c](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/962ea9c))
* **platform:** include MdProgressBar ([83225fa](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/83225fa))
* **platform:** index.ts ([d6cc698](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/d6cc698))
* **platform:** pipes ([e21133a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e21133a))
* **platform:** providers ([bebceb1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/bebceb1))
* **polyfills:** include more operators ([0f6c7bc](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0f6c7bc))
* **rx-examples:** tic-tac-toe ([321e83b](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/321e83b))
* **rx-examples:** tic-tac-toe ([05fd2c6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/05fd2c6))
* **rxjs-examples:** DraggableDiv ([0f2d579](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0f2d579))
* **server:** create api server on port 3001 ([2bf6316](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2bf6316))
* **server:** include express server with WebpackDevServer ([b150a52](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b150a52))
* **server:** include todo api ([b31ea89](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b31ea89))
* **server:** parse text/plain for Http ([0ae672d](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/0ae672d))
* **services:** appServicesInjectables ([8d44599](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/8d44599))
* **services:** create Store for state management ([a673ce1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a673ce1))
* **services:** create todo service ([955c7b1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/955c7b1))
* **shadowDomInjectables:** EmulatedScope if no Native support ([8f2a089](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/8f2a089))
* **shadowDomInjectables:** include more strategies ([2ad9c5f](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2ad9c5f))
* **timeflies/messages:** export bindings ([e2f8405](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/e2f8405))
* **todo:** update forms, add Validators, error message ([49fe89a](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/49fe89a))
* **TodoService:** ITodo interface ([b1c46a1](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/b1c46a1))
* **typings:** include UrlResolver ([91e6dc2](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/91e6dc2))
* **typings:** update angular2 typings ([9376454](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/9376454))
* **typyings:** include more types ([352e59e](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/352e59e))
* **webpack:** add compression plugin ([f9b9cc9](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/f9b9cc9)), closes [#234](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/issue/234)
* **webpack:** default config ([5948f26](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5948f26))
* **webpack:** include env ([5ee01f6](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5ee01f6))
* **webpack.config:** dev/prod env ([efc6d54](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/efc6d54))
* **webpack.config:** devtool cheap-module-eval-source-map ([5e24f11](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/5e24f11))
* **webpack.config:** switch env ([2b29948](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/2b29948))
* **webpack.prod:** minimize html ([a612808](https://bitbucket.org/oliverwymantechssg/ngpd-merceros-ui-starter-kit/commits/a612808))