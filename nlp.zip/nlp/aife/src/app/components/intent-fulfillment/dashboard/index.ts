﻿export * from './intent-fulfillment-dashboard.component';
