﻿export * from './intent-fulfillment-main.component';
