﻿export * from './intent-fulfillment-step2.component';
