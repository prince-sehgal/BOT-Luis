﻿export * from './model-header.component';
