﻿export * from './model-dashboard.component';
