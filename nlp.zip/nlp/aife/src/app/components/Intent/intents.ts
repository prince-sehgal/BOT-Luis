﻿export interface IIntent {
    message: string;
}
