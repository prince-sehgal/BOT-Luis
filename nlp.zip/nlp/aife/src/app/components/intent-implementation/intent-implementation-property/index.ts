export * from './intent-implementation-property.component';
