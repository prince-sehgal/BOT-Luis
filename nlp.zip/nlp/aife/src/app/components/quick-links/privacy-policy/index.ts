export * from './privacy-policy.component';
