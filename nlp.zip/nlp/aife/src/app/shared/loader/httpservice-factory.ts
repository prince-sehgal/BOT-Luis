// import { HttpModule, XHRBackend, RequestOptions } from '@angular/http';
// import { AppHttpService } from './apphttp.service';

// export function HttpServiceFactory(backend: XHRBackend, defaultOptions: RequestOptions) {
//     return new AppHttpService(backend, defaultOptions);
// }
