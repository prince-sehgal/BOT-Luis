import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class IntentModelDataService {
    // private messageSource = new BehaviorSubject('default message');
    // currentModel = this.messageSource.asObservable();
    // currentCategory = this.messageSource.asObservable();

    // constructor() { }

    // changeModel(modelName: string) {
    //     this.messageSource.next(modelName)
    // }
    // changeCategory(categoryName: string) {
    //     this.messageSource.next(categoryName)
    // }
}
