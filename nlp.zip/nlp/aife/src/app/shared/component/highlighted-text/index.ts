export * from './highlighted-text.component';
