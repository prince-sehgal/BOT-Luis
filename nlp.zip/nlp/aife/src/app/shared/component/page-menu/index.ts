﻿export * from './page-menu.component';
