export * from './intentanalysis.component';
