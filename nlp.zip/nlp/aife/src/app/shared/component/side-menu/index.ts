﻿export * from './side-menu.component';
