export const environment = {
  production: true,
  hmr: false,
  // REPLACE_VARS_PLACEHOLDER
};
