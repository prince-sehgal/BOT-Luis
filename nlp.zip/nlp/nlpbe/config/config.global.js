var config = module.exports = {};

config.env = 'development';
config.hostname = 'localhost';
config.port = '5001';
config.python_path = 'C:/Users/manish-kumar5/AppData/Local/Programs/Python/Python36/python';

// Environment values
config.environment = {}
config.environment.development = 'development';
config.environment.test = 'test';
config.environment.production = 'production';


// mongo database
config.mongo = {}
config.mongo.uri = 'mongodb://localhost/eventtrackerdb';


