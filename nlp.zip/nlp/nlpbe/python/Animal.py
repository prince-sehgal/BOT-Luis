import spacy
from spacy.matcher import PhraseMatcher
from spacy.tokens import Span
from spacy.language import Language

class EntityMatcher(object):
    name = 'entity_matcher'

    def __init__(self, nlp, terms, label):
        self.label = nlp.vocab.strings[label]  
        patterns = [nlp(text) for text in terms]
        self.matcher = PhraseMatcher(nlp.vocab)
        self.matcher.add(label, None, *patterns)

    def __call__(self, doc):
        matches = self.matcher(doc)
        for match_id, start, end in matches:
            span = Span(doc, start, end, label=self.label)
            doc.ents = list(doc.ents) + [span]
        return doc

nlp = spacy.load('en')
Language.factories['entity_matcher'] = lambda nlp, **cfg: EntityMatcher(nlp, **cfg)
terms = (u'cat', u'dog', u'tree kangaroo', u'giant sea spider')
#terms = ['cat', 'dog', 'tree kangaroo', 'giant sea spider']
nlp.entity.add_label('ANIMAL')
entity_matcher = EntityMatcher(nlp, terms, 'ANIMAL')
nlp.add_pipe(entity_matcher, last=True)#after='ner'
nlp.entity.add_label('ANIMAL')
print(nlp.pipe_names)  # the components in the pipeline
doc = nlp(U'This is a text about Barack Obama and tree kangaroo')
# doc = nlp(u"This is a text about Barack Obama and a tree kangaroo")
print([(ent.text, ent.label_) for ent in doc.ents])



# import spacy
# import json
# import numpy as np
# from spacy.util import minibatch, compounding
# import sys

# JsonModel = json.load(open('model.json', 'r'))
# # input_Data = "[(\'Have the exceptions changed for the Career business?\', \'Exceptions 107\'), (\'Are there new exceptions for the Career business?\', \'Exceptions 107\'), (\'What has changed for the Career business?\', \'Exceptions 107\')]\r'"

# # "'[('Have the exceptions changed for the Career business?','Exceptions 107'),('Are there new exceptions for the Career business?','Exceptions 107'),('What has changed for the Career business?','Exceptions 107')]'"
# #JsonModel['categories']
# modelname = JsonModel['name']
# print(eval(JsonModel['categories']))
# # TRAIN_DATA = eval(JsonModel['entities'])
# output_dir = modelname
# n_iter = 20

# def dictionerize_cats(y_train):
#     l = []
#     all_labels = np.unique(y_train) 
#     for curr_label in y_train:
#         l.append({cat: bool(cat==curr_label) for cat in all_labels})
#     return l

# X_train = ['Have the exceptions changed for the Career business?','Are there new exceptions for the Career business?']
# Y_train = ['Exceptions 107','Exceptions 107']
# # X_train, Y_train = zip(*input_Data)
# # X_train = "['Have the exceptions changed for the Career business?',Are there new exceptions for the Career business?,What has changed for the Career business?]"
# # Y_train = "['Exceptions 107','Exceptions 107','Exceptions 107']"
# dic_cats = dictionerize_cats(Y_train)
# train_data = list(zip(X_train, [{'cats': cats} for cats in dic_cats]))

# def train_model(model=None, output_dir=None, n_iter=20):
#     # if model is not None:
#     #     nlp = spacy.load(model)  # load existing spaCy model
#     # else:
#     nlp = spacy.blank('en')  # create blank Language class

#     #other_pipes = [pipe for pipe in nlp.pipe_names]
#     if(len(nlp(u'Test').cats) > 0):
#         nlp.disable_pipes('textcat')
    
#     # add the text classifier to the pipeline if it doesn't exist
#     # nlp.create_pipe works for built-ins that are registered with spaCy
#     #if 'textcat' not in nlp.pipe_names:
#     if 'textcat' not in nlp.pipe_names:
#         textcat = nlp.create_pipe('textcat')
#         nlp.add_pipe(textcat, last=True)
#     # otherwise, get it, so we can add labels to it
#     else:
#         textcat = nlp.get_pipe('textcat')

#     # add label to text classifier
#     for cat in np.unique(Y_train):
#         if not cat in textcat.labels:
#             textcat.add_label(cat)

#     # get names of other pipes to disable them during training
#     other_pipes = [pipe for pipe in nlp.pipe_names if pipe != 'textcat']
#     with nlp.disable_pipes(*other_pipes):  # only train textcat
#         optimizer = nlp.begin_training()
#         for i in range(n_iter):
#             losses = {}
#             # batch up the examples using spaCy's minibatch
#             batches = minibatch(train_data, size=compounding(4., 32., 1.001))
#             for batch in batches:
#                 texts, annotations = zip(*batch)
#                 nlp.update(texts, annotations, sgd=optimizer, drop=0.2,
#                            losses=losses)

#     n_iter = 100
#     # create the built-in pipeline components and add them to the pipeline
#     # nlp.create_pipe works for built-ins that are registered with spaCy
#     if 'ner' not in nlp.pipe_names:
#         ner = nlp.create_pipe('ner')
#         nlp.add_pipe(ner, last=True)
#     # otherwise, get it so we can add labels
#     else:
#         ner = nlp.get_pipe('ner')

#     # add labels
#     for _, annotations in TRAIN_DATA:
#         for ent in annotations.get('entities'):
#             ner.add_label(ent[2])

#     # get names of other pipes to disable them during training
#     other_pipes = [pipe for pipe in nlp.pipe_names if pipe != 'ner']
#     with nlp.disable_pipes(*other_pipes):  # only train NER
#         optimizer = nlp.begin_training()
#         for itn in range(n_iter):
#             random.shuffle(TRAIN_DATA)
#             losses = {}
#             for text, annotations in TRAIN_DATA:
#                 nlp.update(
#                     [text],  # batch of texts
#                     [annotations],  # batch of annotations
#                     drop=0.5,  # dropout - make it harder to memorise data
#                     sgd=optimizer,  # callable to update weights
#                     losses=losses)

#     if output_dir is not None:
#         output_dir = Path(output_dir)
#         if not output_dir.exists():
#             output_dir.mkdir()
#         nlp.to_disk(output_dir)
#     print("Training completed successfully")

# train_model(output_dir, output_dir, n_iter)



import spacy
nlp = spacy.load('en')
doc = nlp(u'$100 has been transfered from Mr. Jhon Sr and Mr. Ragav kumar Mohta account to Mr. Prince Sehgal account on 1 August 2018')
for ent in doc.ents:
    # print(ent.lemma)
    print(ent)
