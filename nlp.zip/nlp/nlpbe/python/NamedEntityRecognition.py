import spacy
import sys

nlp = spacy.load('en')
doc = nlp(u'' + sys.argv[1]) 
names = ''
for ent in doc.ents:
    if ent.label_ == 'PERSON':
        names += ent.text + ';'
print(names[:-1])