from pathlib import Path
import random
import spacy
import json
import numpy as np
from spacy.util import minibatch, compounding
import sys
import os

ModelName = ''
Version = ''
Description = ''
Language = ''
Category = ''
Entity = ''

# with open('Format-SpacyTrainingModel.json') as json_file:  
with open(sys.argv[1]) as json_file:  
    data = json.load(json_file)
    ModelName = './python/nlp/' + data['modelName']
    Version = data['versionId']
    Description = data['desc']
    Language = data['culture']

    Category = '['
    Entity = '['
    
    for utterance in data['utterances']:
        Category += "('" + utterance['text'] +"','" + utterance['category'] + "'),"
        entityString = "{'entities': ["
        for entity in utterance['entities']:
            entityString += "(" + str(entity['startIndex']) + "," + str(entity['endIndex']) + ",'" + entity['name'] + "'),"
        if(len(entityString) > 14):
            entityString = entityString[:-1]
        entityString += ']}'
        Entity += "('" + utterance['text'] + "'," + entityString + "),"

    if(len(Category) > 1):
        Category = Category[:-1]
    if(len(Entity) > 1):
        Entity = Entity[:-1]
    Category += ']'
    Entity += ']'

output_dir = ModelName
input_Data = eval(Category)
TRAIN_DATA = eval(Entity)
n_iter = 20

# creating folder with User Name to store NLP model
if not os.path.exists(ModelName):
    os.makedirs(ModelName)

def dictionerize_cats(y_train):
    l = []
    all_labels = np.unique(y_train) 
    for curr_label in y_train:
        l.append({cat: bool(cat==curr_label) for cat in all_labels})
    return l

X_train, Y_train = zip(*input_Data)
dic_cats = dictionerize_cats(Y_train)
train_data = list(zip(X_train, [{'cats': cats} for cats in dic_cats]))

nlp = spacy.load('en')

def train_model(model=None, output_dir=None, n_iter=20):
    # if model is not None:
    #     nlp = spacy.load(model)  # load existing spaCy model
    # else:
    #other_pipes = [pipe for pipe in nlp.pipe_names]
    if(len(nlp(u'Test').cats) > 0):
        nlp.disable_pipes('textcat')
    
    # add the text classifier to the pipeline if it doesn't exist
    # nlp.create_pipe works for built-ins that are registered with spaCy
    #if 'textcat' not in nlp.pipe_names:
    if 'textcat' not in nlp.pipe_names:
        textcat = nlp.create_pipe('textcat')
        nlp.add_pipe(textcat, last=True)
    # otherwise, get it, so we can add labels to it
    else:
        textcat = nlp.get_pipe('textcat')

    # add label to text classifier
    for cat in np.unique(Y_train):
        if not cat in textcat.labels:
            textcat.add_label(cat)

    # get names of other pipes to disable them during training
    other_pipes = [pipe for pipe in nlp.pipe_names if pipe != 'textcat']
    with nlp.disable_pipes(*other_pipes):  # only train textcat
        optimizer = nlp.begin_training()
        for i in range(n_iter):
            losses = {}
            # batch up the examples using spaCy's minibatch
            batches = minibatch(train_data, size=compounding(4., 32., 1.001))
            for batch in batches:
                texts, annotations = zip(*batch)
                nlp.update(texts, annotations, sgd=optimizer, drop=0.2,
                           losses=losses)

def evaluate(tokenizer, textcat, texts, cats):
    docs = (tokenizer(text) for text in texts)
    tp = 1e-8  # True positives
    fp = 1e-8  # False positives
    fn = 1e-8  # False negatives
    tn = 1e-8  # True negatives
    for i, doc in enumerate(textcat.pipe(docs)):
        gold = cats[i]
        for label, score in doc.cats.items():
            if label not in gold:
                continue
            if score >= 0.5 and gold[label] >= 0.5:
                tp += 1.
            elif score >= 0.5 and gold[label] < 0.5:
                fp += 1.
            elif score < 0.5 and gold[label] < 0.5:
                tn += 1
            elif score < 0.5 and gold[label] >= 0.5:
                fn += 1
    precision = tp / (tp + fp)
    recall = tp / (tp + fn)
    f_score = 2 * (precision * recall) / (precision + recall)
    return {'textcat_p': precision, 'textcat_r': recall, 'textcat_f': f_score}

train_model(output_dir, output_dir, n_iter)

def train_entity(model=None, output_dir=None, n_iter=100):
    """Load the model, set up the pipeline and train the entity recognizer."""
    # create the built-in pipeline components and add them to the pipeline
    # nlp.create_pipe works for built-ins that are registered with spaCy
    if 'ner' not in nlp.pipe_names:
        ner = nlp.create_pipe('ner')
        nlp.add_pipe(ner, last=True)
    # otherwise, get it so we can add labels
    else:
        ner = nlp.get_pipe('ner')
    # add labels
    for _, annotations in TRAIN_DATA:
        for ent in annotations.get('entities'):
            ner.add_label(ent[2])

    # get names of other pipes to disable them during training
    other_pipes = [pipe for pipe in nlp.pipe_names if pipe != 'ner']
    with nlp.disable_pipes(*other_pipes):  # only train NER
        optimizer = nlp.begin_training()
        for itn in range(n_iter):
            random.shuffle(TRAIN_DATA)
            losses = {}
            for text, annotations in TRAIN_DATA:
                nlp.update(
                    [text],  # batch of texts
                    [annotations],  # batch of annotations
                    drop=0.5,  # dropout - make it harder to memorise data
                    sgd=optimizer,  # callable to update weights
                    losses=losses)
            #print(losses)
    # for text, _ in TRAIN_DATA: 
    #      doc = nlp(text) 
    #      print('Entities', [(ent.text, ent.label_) for ent in doc.ents]) 
    #      print('Tokens', [(t.text, t.ent_type_, t.ent_iob) for t in doc]) 

    if output_dir is not None:
        output_dir = Path(output_dir)
        if not output_dir.exists():
            output_dir.mkdir()
        nlp.to_disk(output_dir)
        IntentScore =  '[ '
        intentCounter = 0
        for utterance in data['utterances']:
            if(intentCounter > 0):
                IntentScore += ','
            IntentScore += '{"utterance" : "' + utterance['text'] +'"'
            doc = nlp(utterance['text'])
            IntentScore += ', "entities":'+json.dumps(utterance['entities'])+', "scores":' + '[' + str(doc.cats).replace("'", '"') + ']}'
            intentCounter = intentCounter + 1 
        IntentScore +=  ']'
        print(IntentScore)
        #print("Training completed successfully")

train_entity(output_dir, output_dir, n_iter)